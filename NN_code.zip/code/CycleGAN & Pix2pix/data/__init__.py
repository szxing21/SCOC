"""This package includes all the modules related to data loading and preprocessing

 To add a custom dataset class called 'dummy', you need to add a file called 'dummy_dataset.py' and define a subclass 'DummyDataset' inherited from BaseDataset.
 You need to implement four functions:
    -- <__init__>:                      initialize the class, first call BaseDataset.__init__(self, opt).
    -- <__len__>:                       return the size of dataset.
    -- <__getitem__>:                   get a data point from data loader.
    -- <modify_commandline_options>:    (optionally) add dataset-specific options and set default options.

Now you can use the dataset class by specifying flag '--dataset_mode dummy'.
See our template dataset class 'template_dataset.py' for more details.
"""
import os
import re
import numpy as np
import importlib
import torch.utils.data
import matplotlib.pyplot as plt
from data.base_dataset import BaseDataset
import cv2


def find_dataset_using_name(dataset_name):
    """Import the module "data/[dataset_name]_dataset.py".

    In the file, the class called DatasetNameDataset() will
    be instantiated. It has to be a subclass of BaseDataset,
    and it is case-insensitive.
    """
    dataset_filename = "data." + dataset_name + "_dataset"
    datasetlib = importlib.import_module(dataset_filename)

    dataset = None
    target_dataset_name = dataset_name.replace('_', '') + 'dataset'
    for name, cls in datasetlib.__dict__.items():
        if name.lower() == target_dataset_name.lower() \
           and issubclass(cls, BaseDataset):
            dataset = cls

    if dataset is None:
        raise NotImplementedError("In %s.py, there should be a subclass of BaseDataset with class name that matches %s in lowercase." % (dataset_filename, target_dataset_name))

    return dataset


def get_option_setter(dataset_name):
    """Return the static method <modify_commandline_options> of the dataset class."""
    dataset_class = find_dataset_using_name(dataset_name)
    return dataset_class.modify_commandline_options


def create_dataset(opt):
    """Create a dataset given the option.

    This function wraps the class CustomDatasetDataLoader.
        This is the main interface between this package and 'train.py'/'test.py'

    Example:
        >>> from data import create_dataset
        >>> dataset = create_dataset(opt)
    """
    data_loader = CustomDatasetDataLoader(opt)
    dataset = data_loader.load_data()
    # dataset = CustomDataset()
    # data_loader = CustomDatasetDataLoader1(opt,dataset)
    return dataset


class CustomDatasetDataLoader():
    """Wrapper class of Dataset class that performs multi-threaded data loading"""

    def __init__(self, opt):
        """Initialize this class

        Step 1: create a dataset instance given the name [dataset_mode]
        Step 2: create a multi-threaded data loader.
        """
        self.opt = opt
        dataset_class = find_dataset_using_name(opt.dataset_mode)
        self.dataset = dataset_class(opt)
        print("dataset [%s] was created" % type(self.dataset).__name__)
        self.dataloader = torch.utils.data.DataLoader(
            self.dataset,
            batch_size=opt.batch_size,
            shuffle=not opt.serial_batches,
            num_workers=int(opt.num_threads))

    def load_data(self):
        return self

    def __len__(self):
        """Return the number of data in the dataset"""
        return min(len(self.dataset), self.opt.max_dataset_size)

    def __iter__(self):
        """Return a batch of data"""
        for i, data in enumerate(self.dataloader):
            if i * self.opt.batch_size >= self.opt.max_dataset_size:
                break
            yield data


def get_files_in_directory(directory):
        file_names = os.listdir(directory)
        return file_names
        
    
class CustomDataset(torch.utils.data.Dataset):
    def __init__(self):
        path = './results/2/'#'./results/1/portrait/'   './results/1/handbags/'   './results/1/shoes/'     './results/1/maps/'      segmentation
        # date_list = ['2011-08-28 06_44_10', '2012-06-09 19_49_22', '2012-06-12 19_16_15', '2012-06-14 17_12_05', '2012-06-20 12_38_15', '2015-08-04 00_09_46']
        date_list = ['2011-08-18 18_37_21', '2012-06-01 19_37_52', '2012-07-17 07_03_56', '2012-07-17 14_05_09', '2016-05-16 22_12_32', '2016-05-17 01_00_57']
        date = date_list[0]
        
        paths = [['./pic/s2w/'+date+'_real_A.png']]
        name_list = get_files_in_directory(path)
        pattern = r''+date+'_real_A_patch_\d+kernel_(\d+).txt'#r'image_portrait(\d+)Outkernel_\d+\.txt'   r'image_handbags(\d+)Outkernel_\d+\.txt'
        
        indices = []
        for file in name_list:
            if re.search(pattern, file):
                indices += [re.search(pattern, file).group(1)]
        # indices = [re.search(pattern, file).group(1) for file in name_list]
        indices = list(map(int, indices))
        unique_indices = list(set(indices))
        # unique_indices=[4,4,4]
        # print(unique_indices)
        
        S2W_bias = np.loadtxt('./weight/S2W-bias.txt')
        W2S_bias = np.loadtxt('./weight/W2S-bias.txt')
        # print(np.shape(S2W_bias))
        x1 = np.loadtxt(path+date+'_real_A_patch_1kernel_'+str(unique_indices[0])+'.txt')[np.newaxis,:,:]+S2W_bias[0]#np.loadtxt(path+'image_portrait'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]    np.loadtxt(path+'image_handbags'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]
        # print(np.shape(x1))
        for i in range(1,len(unique_indices)):
            image_ij = np.loadtxt(path+date+'_real_A_patch_1kernel_'+str(unique_indices[i])+'.txt')[np.newaxis,:,:]+S2W_bias[i]#np.loadtxt(path+'image_portrait'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]   np.loadtxt(path+'image_handbags'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]
            x1 = np.concatenate((x1, image_ij))
        x2 = np.loadtxt(path+date+'_real_A_patch_2kernel_'+str(unique_indices[0])+'.txt')[np.newaxis,:,:]+S2W_bias[0]#np.loadtxt(path+'image_portrait'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]    np.loadtxt(path+'image_handbags'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]
        for i in range(1,len(unique_indices)):
            image_ij = np.loadtxt(path+date+'_real_A_patch_2kernel_'+str(unique_indices[i])+'.txt')[np.newaxis,:,:]+S2W_bias[i]#np.loadtxt(path+'image_portrait'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]   np.loadtxt(path+'image_handbags'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]
            x2 = np.concatenate((x2, image_ij))    
        x2 = x2[:,1:,:]
        x1, x2 = np.transpose(x1,(0,2,1)), np.transpose(x2,(0,2,1))
        x = np.concatenate((x1, x2),2)


        x = x.reshape(1,64,256,255)
        
        
        # for i in range(2):
        #     date = date_list[i]
            
        #     paths = [['./pic/w2s/'+date+'_real_B.png']]
        #     name_list = get_files_in_directory(path)
        #     pattern = r''+date+'_real_B_patch_\d+kernel_(\d+).txt'#r'image_portrait(\d+)Outkernel_\d+\.txt'   r'image_handbags(\d+)Outkernel_\d+\.txt'
            
        #     indices = []
        #     for file in name_list:
        #         if re.search(pattern, file):
        #             indices += [re.search(pattern, file).group(1)]
        #     # indices = [re.search(pattern, file).group(1) for file in name_list]
        #     indices = list(map(int, indices))
        #     unique_indices = list(set(indices))
        #     # unique_indices=[4,4,4]
        #     # print(unique_indices)
            
        #     S2W_bias = np.loadtxt('./weight/S2W-bias.txt')
        #     W2S_bias = np.loadtxt('./weight/W2S-bias.txt')
        #     # print(np.shape(S2W_bias))
        #     x1 = np.loadtxt(path+date+'_real_B_patch_1kernel_'+str(unique_indices[0])+'.txt')[np.newaxis,:,:]+W2S_bias[0]#np.loadtxt(path+'image_portrait'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]    np.loadtxt(path+'image_handbags'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]
        #     # print(np.shape(x1))
        #     for i in range(1,len(unique_indices)):
        #         image_ij = np.loadtxt(path+date+'_real_B_patch_1kernel_'+str(unique_indices[i])+'.txt')[np.newaxis,:,:]+W2S_bias[i]#np.loadtxt(path+'image_portrait'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]   np.loadtxt(path+'image_handbags'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]
        #         x1 = np.concatenate((x1, image_ij))
        #     x2 = np.loadtxt(path+date+'_real_B_patch_2kernel_'+str(unique_indices[0])+'.txt')[np.newaxis,:,:]+W2S_bias[0]#np.loadtxt(path+'image_portrait'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]    np.loadtxt(path+'image_handbags'+str(unique_indices[0])+'Outkernel_'+str(1)+'.txt')[np.newaxis,:,:]
        #     for i in range(1,len(unique_indices)):
        #         image_ij = np.loadtxt(path+date+'_real_B_patch_2kernel_'+str(unique_indices[i])+'.txt')[np.newaxis,:,:]+W2S_bias[i]#np.loadtxt(path+'image_portrait'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]   np.loadtxt(path+'image_handbags'+str(unique_indices[i])+'Outkernel_'+str(j)+'.txt')[np.newaxis,:,:]
        #         x2 = np.concatenate((x2, image_ij))    
        #     x2 = x2[:,1:,:]
        #     # x1, x2 = np.transpose(x1,(0,2,1)), np.transpose(x2,(0,2,1))
        #     x_tmp = np.concatenate((x1, x2),1)

        #     x_tmp = x_tmp.reshape(1,64,255,256)


        # print(np.shape(x))
        # x = x.reshape(3,-1)
        # x = np.concatenate([x[:,2:],np.array(x[:,0:2])],1)
        # x = x.reshape(3,64,128,128)
        # print(x[0][0][0],x[1][0][0],x[2][0][0])
        # print(np.shape(x))
        x = torch.Tensor(x)#.tolist()
        
        # img_path = ['./datasets/0/edges2portrait/image_portrait18.png','./datasets/0/edges2portrait/image_portrait26.png','./datasets/0/edges2portrait/image_portrait29.png']
        # img_path = ['./datasets/0/edges2handbags/image_handbags4.png','./datasets/0/edges2handbags/image_handbags19.png','./datasets/0/edges2handbags/image_handbags30.png']
        img_path = ['./pic/pic-fake/s2w/'+date+'_fake_B.png']
        # img1 = np.flip(cv2.imread(img_path[0], cv2.IMREAD_GRAYSCALE),0)[1:-1, 1:-1][np.newaxis,:,:]  # 以灰度模式读取图片
        # img2 = np.flip(cv2.imread(img_path[1], cv2.IMREAD_GRAYSCALE),0)[1:-1, 1:-1][np.newaxis,:,:]  # 以灰度模式读取图片
        # img3 = np.flip(cv2.imread(img_path[2], cv2.IMREAD_GRAYSCALE),0)[1:-1, 1:-1][np.newaxis,:,:]  # 以灰度模式读取图片
        # init_image_A = np.concatenate((img1, img2, img3)).reshape(3,1,1,128,128)
        # init_image_A = torch.Tensor(init_image_A)/255
        # print(np.shape(cv2.imread(img_path[0], cv2.IMREAD_COLOR)))
        img1 = np.flip(np.transpose(cv2.imread(img_path[0], cv2.IMREAD_COLOR),(2,1,0)),0).copy()
        # print(np.shape(img1))
        init_image_A =  img1.reshape(1,3,256,256)
        init_image_A = torch.Tensor(init_image_A)/255
        # print(init_image_A.size())
        init_image_B = init_image_A
        
        # img_path = ['./datasets/0/edges2portrait/image'+str(unique_indices[0])+'.png','./datasets/0/edges2portrait/image'+str(unique_indices[1])+'.png','./datasets/0/edges2portrait/image'+str(unique_indices[2])+'.png']
        # img1 = np.flip(np.transpose(cv2.imread(img_path[0], cv2.IMREAD_COLOR),(2,0,1)),0)[np.newaxis,:,:,:]
        # img2 = np.flip(np.transpose(cv2.imread(img_path[1], cv2.IMREAD_COLOR),(2,0,1)),0)[np.newaxis,:,:,:]
        # img3 = np.flip(np.transpose(cv2.imread(img_path[2], cv2.IMREAD_COLOR),(2,0,1)),0)[np.newaxis,:,:,:]
        # init_image_B = np.concatenate((img1, img2, img3)).reshape(3,1,3,128,128)
        # init_image_B = torch.Tensor(init_image_B)/255
        
        
        # y1 = torch.Tensor(np.loadtxt('./results/0/1.txt').reshape(64,128,128)[np.newaxis,:,:])
        # y2 = torch.Tensor(np.loadtxt('./results/0/2.txt').reshape(64,128,128)[np.newaxis,:,:])
        # y3 = torch.Tensor(np.loadtxt('./results/0/3.txt').reshape(64,128,128)[np.newaxis,:,:])
        # y = torch.cat([y1,y2,y3],0)
        # x = torch.cat([x[:,:16,:,:],y[:,16:,:,:]],1)
        # # # y01 = torch.Tensor(np.loadtxt('./results/0/10.txt').reshape(64,128,128)[np.newaxis,:,:])
        # # # y02 = torch.Tensor(np.loadtxt('./results/0/20.txt').reshape(64,128,128)[np.newaxis,:,:])
        # # y03 = torch.Tensor(np.loadtxt('./results/0/30.txt').reshape(64,128,128))
        # # # y0 = torch.cat([y01,y02,y03],0)
        # # # print(y.size())
        
        # # error_matrix = torch.sum(torch.abs(x[2]-y03),0).view(-1)
        # # error_matrix1 = torch.sum(torch.abs(y3 - y03), 0).view(-1)
        # # error_matrix = torch.sum(abs(x[2]),0).view(-1)
        # # error_matrix1 = torch.sum(abs(y3), 0).view(-1)
        # # error_matrix1 = error_matrix1 - error_matrix
        # # error_matrix = (x[2][-1]).view(-1) - y03[-1].view(-1)
        # # error_matrix1 = (y3[0]).view(-1) - y03[-1].view(-1)
        # # # print(torch.max(x[0]),torch.min(abs(x[0])))
        # # print(torch.max(error_matrix),torch.mean(abs(error_matrix)))
        # # print(torch.max(error_matrix1),torch.mean(abs(error_matrix1)))
        
        # # error_matrix_np = error_matrix.numpy().reshape(128,128)
        # # error_matrix_np1 = error_matrix1.numpy().reshape(128,128)
        # # plt.figure(figsize=(8, 6))
        # # plt.imshow(error_matrix_np, cmap='hot', interpolation='nearest')
        # # plt.colorbar(label='Error')
        # # plt.title('Error Heatmap')
        # # plt.xlabel('Column Index')
        # # plt.ylabel('Row Index')
        # # plt.show()
        # # plt.figure(figsize=(8, 6))
        # # plt.imshow(error_matrix_np1, cmap='hot', interpolation='nearest')
        # # plt.colorbar(label='Error')
        # # plt.title('Error Heatmap')
        # # plt.xlabel('Column Index')
        # # plt.ylabel('Row Index')
        # # plt.show()
        # # plt.figure(figsize=(8, 6))
        # # # plt.hist((x[2]).view(-1)-y03.view(-1), bins=300, color='blue', alpha=0.3,range=(-0.05,0.05))
        # # # plt.hist(y3.view(-1)-y03.view(-1), bins=300, color='red', alpha=0.3,range=(-0.05,0.05))
        # # plt.hist((x[2]-y03).view(-1), bins=3000, color='blue', alpha=0.3)
        # # plt.hist((y3-y03).view(-1), bins=3000, color='red', alpha=0.3)
        # # # plt.hist(y03.view(-1), bins=300, color='green', alpha=0.3)
        # # plt.xlabel('Value')
        # # plt.ylabel('Frequency')
        # # plt.show()
        self.data=[]
        index_i = 0
        for i in range(index_i, len(x)-index_i):
            if i == 1 and i == 4:
                pass
            else:
                self.data.append({'x':x[i],'paths':paths[i],'A':init_image_A[i],'B':init_image_B[i]})
            # self.data.append({'x':x[i],'paths':paths[i]})
        print('# samples: {}'.format(len(self.data)))
    def __len__(self):
        return len(self.data)
    def __getitem__(self, item):
        return self.data[item]

class CustomDatasetDataLoader1():
    def __init__(self, opt, dataset):
        self.opt = opt
        self.dataset = dataset
        self.dataloader = torch.utils.data.DataLoader(
            self.dataset,
            batch_size=1,
            shuffle=False,
            num_workers=0)
    def load_data(self):
        return self
    def __len__(self):
        return len(self.data)
    def __iter__(self):
        """Return a batch of data"""
        for i, data in enumerate(self.dataloader):
            yield data