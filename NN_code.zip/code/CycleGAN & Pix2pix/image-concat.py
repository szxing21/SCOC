import skimage.io as io
import skimage.util
import numpy as np
import os
import matplotlib.pyplot as plt
dir_path1 = "datasets/1/test/zzzzz/t/01"
 
dir_path2 = "datasets/1/test/zzzzz/t/02"
 
files = os.listdir(dir_path1)
 
 
# from PIL import Image
 
# def resize_images(image1_path, image2_path, new_width, new_height):
#     with Image.open(image1_path) as img1, Image.open(image2_path) as img2:
#         img1_resized = img1.resize((new_width, new_height), Image.ANTIALIAS)
#         img2_resized = img2.resize((new_width, new_height), Image.ANTIALIAS)
 
#         img1_resized.save(image1_path)
#         img2_resized.save(image2_path)
 
# # 使用示例
# resize_images(dir_path1+'/5.png', dir_path2+'/5.png', 800, 600)
 
 
 
 
for file in files:
    im1 = io.imread(dir_path1 + '/' + file)  # np.ndarray, [h, w, c], 值域(0, 255), RGB
    # im1 = skimage.util.invert(im1)
    # plt.imshow(im1)   #查看图片
    # plt.show()
 
    im2 = io.imread(dir_path2 + '/' + file)  # np.ndarray, [h, w, c], 值域(0, 255), RGB
    # plt.imshow(im2)
    # plt.show()
 
    # print(im1.shape)   #查看图片的大小
    # print(im1.dtype)   #查看数组元素数据类型
    # print(im2.shape)
    # print(im2.dtype)
    (a,b,c) = np.shape(im1)
    
    im3 = np.zeros((a, b+b,c))  # 横向拼接
    print(np.shape(im1))
    im3[:, :b,:] = im1.copy()  # im1在左
    im3[:, b:,:] = im2.copy()  # im2在右
    print(np.shape(im3))
    # print(im3.dtype)   #查看数组元素类型
 
    im3 = np.array(im3, dtype=np.uint8)  # 将pj1数组元素数据类型的改为"uint8"
 
    # plt.imshow(im3)   #查看拼接情况
    # plt.show()
 
    io.imsave('datasets/1/test/zzzzz/t/00/' + file, im3)  # 保存拼接后的图片
