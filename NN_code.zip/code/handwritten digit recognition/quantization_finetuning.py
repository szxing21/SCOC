import numpy as np
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader, SequentialSampler, RandomSampler
from quantization_train import quantize_tensor, QuantizedReLU, QuantizedMaxPool2d, QuantizedConv2d, QuantizedLinear, Net
from PIL import Image
import re
import matplotlib.pyplot as plt
import seaborn as sns
import random
from sklearn.metrics import confusion_matrix

torch.cuda.manual_seed(3407)

# 定义神经网络模型
# class Net_1(nn.Module):
#     def __init__(self, bit_width, scale):
#         super(Net_1, self).__init__()
#         self.conv1 = QuantizedConv2d(1, 6, 3, bit_width, scale)
#         self.relu1 = QuantizedReLU(bit_width, scale)
#         self.maxpool1 = QuantizedMaxPool2d(bit_width, scale)
#         self.conv2 = QuantizedConv2d(6, 16, 3, bit_width, scale)
#         self.relu2 = QuantizedReLU(bit_width, scale)
#         self.maxpool2 = QuantizedMaxPool2d(bit_width, scale)
#         self.conv3 = QuantizedConv2d(16, 32, 3, bit_width, scale)
#         self.relu3 = QuantizedReLU(bit_width, scale)
        
#         self.fc2 = QuantizedLinear(32 * 3 * 3, 10, bit_width, scale)
        
#     def forward(self, x):
#         x = self.relu1(self.maxpool1(x))
#         x = self.relu2(self.maxpool2(self.conv2(x)))
#         x = self.relu3(self.conv3(x))
#         x = x.view(-1, 32 * 3 * 3)
#         x = self.fc2(x)
#         return x
class Net_1(nn.Module):
    def __init__(self, bit_width, scale):
        super(Net_1, self).__init__()
        self.conv1 = QuantizedConv2d(1, 6, 3, bit_width, scale)
        self.relu1 = QuantizedReLU(bit_width, scale)
        self.maxpool1 = QuantizedMaxPool2d(bit_width, scale)

        self.fc1 = QuantizedLinear(6 * 13 * 13, 10, bit_width, scale)


    def forward(self, x):
        x = self.relu1(self.maxpool1(x))
        x = x.view(-1, 6 * 13 * 13)
        x = self.fc1(x)
        return x

    
class MyDataSet(Dataset):
    def __init__(self, images, labels):
        self.data=[]
        for i in range(len(images)):
            self.data.append({'images':images[i],'labels':labels[i],})
        print('# samples: {}'.format(len(self.data)))
    def __len__(self):
        return len(self.data)
    def __getitem__(self, item):
        return self.data[item]

def collate(batch):
    images, labels = [], []
    for i in batch:
        images.append(i['images'])
        labels.append(i['labels'])
    if len(batch)!=1:
        for i in range(128-len(batch)):
            images.append([[0]*26*26]*6)
            labels.append(0)
    batch_images = torch.Tensor(np.array(images))
    batch_labels = torch.Tensor(np.array(labels))
    return batch_images, batch_labels

if __name__ == "__main__":
    # 初始化参数
    num_bits = 5  # 指定量化的位数
    scale = 1.0 / (2.0 ** (num_bits-1))
    
    import os
    
    def get_files_in_directory(directory):
        file_names = os.listdir(directory)
        return file_names
        
    name_list = get_files_in_directory('./out1_data/pic_conv_new/')
    # print(name_list)
    # image95Outkernel_3.txt
    
    pattern = r'image(\d+)Outkernel_\d+\.txt'
    indices = [re.search(pattern, file).group(1) for file in name_list]
    indices = list(map(int, indices))
    unique_indices = list(set(indices))
    print(unique_indices)

    bias = np.loadtxt('./weight_new/'+str(num_bits)+'bit-conv1.conv2d.bias.txt').tolist()
    labels = np.loadtxt('./data/label.txt').tolist()
    images_list, label_list = [], []
    # f_list = [0,1,2,5,6,8,10,11,12,13,15,16,17,18,19,21,30,35,61,84]
    f_list = [5, 47, 93, 106, 46, 87, 89, 49, 70, 1, 102, 22, 78, 99, 97, 25, 86, 15, 67, 37]
    # f_list = random.sample(unique_indices, 20)
    np.savetxt('./index/f_list.txt', f_list, fmt='%d')
    print(f_list)
    for i in f_list:
        path = './out1_data/pic_conv_new/image'+str(i)+'Outkernel_'
        image_1 = np.loadtxt(path+'1.txt')+bias[0]
        image_2 = np.loadtxt(path+'2.txt')+bias[1]
        image_3 = np.loadtxt(path+'3.txt')+bias[2]
        image_4 = np.loadtxt(path+'4.txt')+bias[3]
        image_5 = np.loadtxt(path+'5.txt')+bias[4]
        image_6 = np.loadtxt(path+'6.txt')+bias[5]
        # print(np.array(image_1))
        image_array_1,image_array_2,image_array_3,image_array_4,image_array_5,image_array_6 = np.array(image_1)[np.newaxis,:,:],np.array(image_2)[np.newaxis,:,:],np.array(image_3)[np.newaxis,:,:],np.array(image_4)[np.newaxis,:,:],np.array(image_5)[np.newaxis,:,:],np.array(image_6)[np.newaxis,:,:]
        images = (np.concatenate([image_array_1,image_array_2,image_array_3,image_array_4,image_array_5,image_array_6],0)/1)[np.newaxis,:,:,:].reshape(1,6,-1).tolist()
        images_list.append(images)
        label_list.append(labels[i])
        
    
    train_set = MyDataSet(images_list, label_list)    
    

    # train_sampler = SequentialSampler(data_source=test_set)
    train_sampler = RandomSampler(data_source=train_set)
    train_loader = DataLoader(train_set, batch_size=1, sampler=train_sampler, num_workers=0, collate_fn=collate)

    criterion = nn.CrossEntropyLoss()
    # 定义测试函数
    def train(model, criterion, optimizer, train_loader, num_epochs=5):
        model.train()
        for epoch in range(num_epochs):
            for images, labels in train_loader:
                images, labels = images.to('cuda'), labels.to('cuda')
                optimizer.zero_grad()
                outputs, _ = model(images)
                # print(torch.argmax(outputs[0]), labels[0])
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
    
    
    def finetuning(model, criterion, optimizer, train_loader, num_epochs=5):
        model.train()
        for epoch in range(num_epochs):
            correct = 0
            top2_acc,top3_acc = 0, 0
            total = 0
            loss = 0
            pre_label = []
            target_label = []
            for images, labels in train_loader:
                images, labels = images.to('cuda'), labels.to('cuda')
                images = images.squeeze().view(-1,6,26,26)
                optimizer.zero_grad()
                outputs = model(images)
                loss = criterion(outputs, labels.long())
                loss.backward()
                optimizer.step()

                _, topk_indices2 = torch.topk(outputs, 2, dim=1)
                _, topk_indices3 = torch.topk(outputs, 3, dim=1)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                top2_acc += int(labels in topk_indices2)
                top3_acc += int(labels in topk_indices3)
                pre_label.append(int(predicted.cpu().numpy()))
                target_label.append(int(labels.cpu().numpy()))
            loss = loss/20
            accuracy = 100 * correct / total
            top2_acc = 100 * top2_acc / total
            top3_acc = 100 * top3_acc / total
            print(loss, accuracy, top2_acc, top3_acc)
        return accuracy,top2_acc,top3_acc,pre_label,target_label


    model = Net_1(num_bits, scale).to('cuda')
    model.load_state_dict(torch.load('./weight_new/mnist_bs128_lr1e-3_epoch5_'+str(num_bits)+'bits.pth'))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    # 测试模型
    accuracy_original,top2_acc,top3_acc,a,b = finetuning(model, criterion, optimizer, train_loader, 5)
    print("Quantized Model ({} bit) Test-Accuracy: {:.2f}%".format(num_bits, accuracy_original))
    print("Quantized Model ({} bit) Test-Top2_Accuracy: {:.2f}%".format(num_bits, top2_acc))
    print("Quantized Model ({} bit) Test-Top3_Accuracy: {:.2f}%".format(num_bits, top3_acc))
    
    torch.save(model.state_dict(), './weight_new/mnist_bs128_lr1e-3_epoch5_'+str(num_bits)+'bits_finetuning.pth')
    # # 计算混淆矩阵
    # cm = confusion_matrix(b, a)

    # # 使用Seaborn绘制混淆矩阵
    # plt.figure(figsize=(8, 6))
    # sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    # plt.xlabel('Predicted labels')
    # plt.ylabel('True labels')
    # plt.title('Confusion Matrix')
    # plt.show()