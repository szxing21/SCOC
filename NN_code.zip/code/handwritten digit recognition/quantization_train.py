import numpy as np
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torch.quantization import QuantStub, DeQuantStub, quantize, prepare, convert
torch.cuda.manual_seed(1123)

def quantize_tensor(x, scale, zero_point=0, num_bits=8, signed=False):
    # if signed:
    #     qmin = -2**(num_bits-1)
    #     qmax = 2**(num_bits-1) - 1
    # else:
    #     qmin = 0
    #     qmax = 2**num_bits - 1

    # q_x = zero_point + x / scale
    # q_x.clamp_(qmin, qmax).round_()
    # print(x.size())
    
    crop_x = x / scale
    x_min = torch.min(crop_x)
    x_max = torch.max(crop_x)
    std_err = (x_max-x_min)/2**num_bits
    q_x = crop_x + std_err*torch.randn(x.size()).cuda()
    q_x = q_x * scale
    
    # crop_x = x / scale
    # noise_m = torch.randn(x.size()).cuda()
    
    # for i in range(len(x)):
    #     crop_xi = crop_x[i]
    #     x_min = torch.min(crop_xi)
    #     x_max = torch.max(crop_xi)
    #     std_err = (x_max-x_min)/2**num_bits
    #     noise_m = noise_m*std_err
    # q_x = crop_x + noise_m
    # q_x = q_x * scale
        
    return q_x
# class QuantizeFunction(torch.autograd.Function):
#     @staticmethod
#     def forward(ctx, x, scale, zero_point, qmin, qmax):
#         q_x = zero_point + x / scale
#         q_x.clamp_(qmin, qmax).round_()
#         return q_x

#     @staticmethod
#     def backward(ctx, grad_output):
#         # Straight-Through Estimator
#         return grad_output, None, None, None, None

# def quantize_tensor(x, scale, zero_point=0, num_bits=8, signed=False):
#     if signed:
#         qmin = -2**(num_bits-1)
#         qmax = 2**(num_bits-1) - 1
#     else:
#         qmin = 0
#         qmax = 2**num_bits - 1

#     return QuantizeFunction.apply(x, scale, zero_point, qmin, qmax)

# 定义自定义的ReLU层，用于量化
class QuantizedReLU(nn.Module):
    def __init__(self, num_bits, scale):
        super(QuantizedReLU, self).__init__()
        self.num_bits = num_bits
        self.scale = scale
        self.relu = nn.ReLU()

    def forward(self, x):
        # # 对输入进行带符号量化
        # quant_x = quantize_tensor(x, self.scale, 0, self.num_bits, True)
        # # 量化后进行ReLU操作
        # quantized_output = self.relu(quant_x) * self.scale
        
        quantized_output = self.relu(x)
        quantized_output = quantize_tensor(quantized_output, self.scale, 0, self.num_bits, True)
        return quantized_output

# 定义自定义的MaxPooling层，用于量化
class QuantizedMaxPool2d(nn.Module):
    def __init__(self, num_bits, scale):
        super(QuantizedMaxPool2d, self).__init__()
        self.num_bits = num_bits
        self.scale = scale
        self.max_pool = nn.MaxPool2d(2, 2)

    def forward(self, x):
        # # 对输入进行带符号量化
        # quant_x = quantize_tensor(x, self.scale, 0, self.num_bits, True)
        # # 量化后进行MaxPooling操作
        # quantized_output = self.max_pool(quant_x) * self.scale
        
        quantized_output = self.max_pool(x)
        quantized_output = quantize_tensor(quantized_output, self.scale, 0, self.num_bits, True)
        return quantized_output
    
# 定义自定义的Conv2d层，用于量化
class QuantizedConv2d(nn.Module):
    def __init__(self, In_channel, Out_channel, Kernel_size, num_bits, scale):
        super(QuantizedConv2d, self).__init__()
        self.num_bits = num_bits
        self.scale = scale
        self.conv2d = nn.Conv2d(In_channel, Out_channel, Kernel_size)

    def forward(self, x):
        # # 对输入进行带符号量化
        # quant_x = quantize_tensor(x, self.scale, 0, self.num_bits, True)
        
        # # 对网络权重及偏置进行带符号量化
        # # print(self.conv2d.weight.data)
        # # self.conv2d.weight.data = quantize_tensor(self.conv2d.weight.data, self.scale, 0, self.num_bits, True) * self.scale
        # # self.conv2d.bias.data = quantize_tensor(self.conv2d.bias.data, self.scale, 0, self.num_bits, True) * self.scale
        # # print(self.conv2d.weight.data)
        
        # # 量化后进行Conv2d操作
        # quantized_output = self.conv2d(quant_x) * self.scale
        
        
        # self.conv2d.weight.data = quantize_tensor(self.conv2d.weight.data, self.scale, 0, self.num_bits, True) * self.scale
        # self.conv2d.bias.data = quantize_tensor(self.conv2d.bias.data, self.scale, 0, self.num_bits, True) * self.scale
        quantized_output = self.conv2d(x)
        quantized_output = quantize_tensor(quantized_output, self.scale, 0, self.num_bits, True)
        return quantized_output
    
# 定义自定义的Linear层，用于量化
class QuantizedLinear(nn.Module):
    def __init__(self, In_size, Out_size, num_bits, scale):
        super(QuantizedLinear, self).__init__()
        self.num_bits = num_bits
        self.scale = scale
        self.linear = nn.Linear(In_size, Out_size)

    def forward(self, x):
        # # 对输入进行带符号量化
        # quant_x = quantize_tensor(x, self.scale, 0, self.num_bits, True)
        
        # # 对网络权重及偏置进行带符号量化
        # # print(self.linear.weight.data)
        # # self.linear.weight.data = quantize_tensor(self.linear.weight.data, self.scale, 0, self.num_bits, True) * self.scale
        # # self.linear.bias.data = quantize_tensor(self.linear.bias.data, self.scale, 0, self.num_bits, True) * self.scale
        # # print(self.linear.weight.data)
        
        # # 量化后进行linear操作
        # quantized_output = self.linear(quant_x) * self.scale
        
        
        # self.linear.weight.data = quantize_tensor(self.linear.weight.data, self.scale, 0, self.num_bits, True) * self.scale
        # self.linear.bias.data = quantize_tensor(self.linear.bias.data, self.scale, 0, self.num_bits, True) * self.scale
        quantized_output = self.linear(x)
        quantized_output = quantize_tensor(quantized_output, self.scale, 0, self.num_bits, True)
        # print(self.linear.weight.data)
        # print(quantized_output[0])
        return quantized_output

# 定义神经网络模型
class Net(nn.Module):
    def __init__(self, bit_width, scale):
        super(Net, self).__init__()
        # self.conv1 = QuantizedConv2d(1, 6, 3, bit_width, scale)
        # self.relu1 = QuantizedReLU(bit_width, scale)
        # self.maxpool1 = QuantizedMaxPool2d(bit_width, scale)
        # self.conv2 = QuantizedConv2d(6, 16, 3, bit_width, scale)
        # self.relu2 = QuantizedReLU(bit_width, scale)
        # self.maxpool2 = QuantizedMaxPool2d(bit_width, scale)

        # self.fc1 = QuantizedLinear(16 * 5 * 5, 120, bit_width, scale)
        # self.relu4 = QuantizedReLU(bit_width, scale)
        # self.fc2 = QuantizedLinear(120, 10, bit_width, scale)
        
        self.conv1 = QuantizedConv2d(1, 6, 3, bit_width, scale)
        self.relu1 = QuantizedReLU(bit_width, scale)
        self.maxpool1 = QuantizedMaxPool2d(bit_width, scale)

        self.fc1 = QuantizedLinear(6 * 13 * 13, 10, bit_width, scale)
        # self.relu4 = QuantizedReLU(bit_width, scale)
        # self.fc2 = QuantizedLinear(120, 10, bit_width, scale)


    def forward(self, x):
        out1_data = self.conv1(x)
    
        # x = self.relu1(self.maxpool1(self.conv1(x)))
        # x = self.relu2(self.maxpool2(self.conv2(x)))
        # x = x.view(-1, 16 * 5 * 5)
        # x = self.relu4(self.fc1(x))
        # x = self.fc2(x)
        
        x = self.relu1(self.maxpool1(self.conv1(x)))
        # print(x.size())
        x = x.view(-1, 6 * 13 * 13)
        x = self.fc1(x)
        # x = self.relu4(self.fc1(x))
        # x = self.fc2(x)

        return x, out1_data

class Net_new(nn.Module):
    def __init__(self, bit_width, scale):
        super(Net_new, self).__init__()
        self.conv1 = QuantizedConv2d(1, 6, 3, bit_width, scale)
        self.relu1 = nn.ReLU()
        self.maxpool1 = QuantizedMaxPool2d(bit_width, scale)

        self.fc1 = QuantizedLinear(6 * 13 * 13, 10, bit_width, scale)


    def forward(self, x):
        out1_data = self.conv1(x)
        x = self.relu1(self.maxpool1(self.conv1(x)))
        x = x.view(-1, 6 * 13 * 13)
        x = self.fc1(x)

        return x, out1_data


if __name__ == "__main__":
    # 准备数据集
    batch_size = 64
    # transform = transforms.Compose([transforms.RandomHorizontalFlip(), transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]) 
    
    transform = transforms.Compose([transforms.RandomHorizontalFlip(), transforms.ToTensor(),])    
    # transform = transforms.Compose([transforms.Resize(64), transforms.RandomHorizontalFlip(), transforms.ToTensor()])   
    train_dataset = torchvision.datasets.MNIST(root='./data', train=True, transform=transform, download=True)
    test_dataset = torchvision.datasets.MNIST(root='./data', train=False, transform=transform, download=True)
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)
    train_loader1 = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=False)
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=batch_size, shuffle=False)
    # target_list = []
    # print(test_dataset[0])
    # for i in range(len(test_dataset)):
    #     img, target = test_dataset[i]
    #     torchvision.utils.save_image(img, './jpg/image'+str(i)+'.png')
    #     target_list.append(target)
    # target_list = np.array(target_list)
    # np.savetxt('./jpg/label.txt',target_list)
        
    # 定义训练函数
    def train(model, criterion, optimizer, train_loader, num_epochs=5):
        model.train()
        for epoch in range(num_epochs):
            for images, labels in train_loader:
                images, labels = images.to('cuda'), labels.to('cuda')
                optimizer.zero_grad()
                outputs, _ = model(images)
                # print(torch.argmax(outputs[0]), labels[0])
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

    # 定义测试函数
    def test(model, test_loader):
        model.eval()
        correct = 0
        total = 0
        out1_data_list = []
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to('cuda'), labels.to('cuda')
                outputs, out1_data = model(images)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                out1_data_list.append(out1_data.cpu().numpy())
        accuracy = 100 * correct / total
        
        out1_data_list_flat = out1_data_list[0]
        for i in range(1, len(out1_data_list)):
            out1_data_list_flat = np.concatenate((out1_data_list_flat, out1_data_list[i]), 0)
        out1_data_list = out1_data_list_flat
        return accuracy, out1_data_list

    # 初始化模型和训练参数
    num_epochs = 5
    num_bits = 5  # 指定量化的位数
    # scale = 1.0 / (2.0 ** (num_bits-3)) # 指定量化的小数位数1_5-0 6-1 7、8-2 9-1
    scale = 1.0 / (2.0 ** (num_bits-1))
    # model = Net(num_bits, scale).to('cuda')
    model = Net_new(num_bits, scale).to('cuda')
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)



    model.load_state_dict(torch.load('./weight_new/mnist_bs128_lr1e-3_epoch5_'+str(num_bits)+'bits.pth'))
    for name, param in model.named_parameters():
        # print(name)
        if name in ['conv1.conv2d.weight']:
            param.requires_grad = False
            print(param)
    # # 训练原始模型
    # train(model, criterion, optimizer, train_loader, num_epochs)
    # # # # 保存模型
    # torch.save(model.state_dict(), './weight_new/mnist_bs128_lr1e-3_epoch5_'+str(num_bits)+'bits.pth')
    
    # # # 加载模型
    # # model.load_state_dict(torch.load('./model/mnist_bs128_lr1e-3_epoch5_'+str(num_bits)+'bits.pth'))
    
    # 测试原始模型
    accuracy_original, _ = test(model, train_loader1)
    print("Quantized Model ({} bit) Train-Accuracy: {:.2f}%".format(num_bits, accuracy_original))

    # accuracy_original, out1_data_list = test(model, test_loader)
    # print("Quantized Model ({} bit) Test-Accuracy: {:.2f}%".format(num_bits, accuracy_original))    
    
    # for name, param in model.named_parameters():
    #     if name in ['conv1.conv2d.weight']:
    #         print(param)
    
    # # 保存测试集
    # # print(test_dataset.data.size(), test_dataset.targets.size())
    # np.savetxt('./data/image.txt', test_dataset.data.numpy().reshape(10000, -1))
    # np.savetxt('./data/label.txt', test_dataset.targets.numpy())
    
    # # 保存模型第一层卷积后输出
    # # print(np.shape(out1_data_list))
    # out1_data_list = out1_data_list.reshape(10000, -1)
    # np.savetxt('./out1_data/'+str(num_bits)+'bit-out1.txt', out1_data_list)
    
    # # # 保存模型第一层权重
    # for name,param in model.named_parameters():
    #     # print(name,param)
    #     if name == 'conv1.conv2d.weight' or name == 'conv1.conv2d.bias':
    #         print(param)
    #         param = param.squeeze()
    #         param = param.cpu().detach().numpy()
    #         with open("./weight_new/"+str(num_bits)+"bit-{}.txt".format(name), 'w') as f:
    #             for i in range(len(param)):
    #                 f.write(str(param[i].tolist()) + '\n')
    #         print(np.shape(param))
    #         # param.tofile("./weight/"+str(num_bits)+"bit-{}.txt".format(name))
    #         # print(param)
    #     # param = param.cpu().detach().numpy()
    #     # param.tofile("./weight/"+str(num_bits)+"bit-{}.bin".format(name))
            
    # # # # for name,param in model.named_parameters():
    # # # #     if name == 'conv2.conv2d.weight' or name == 'conv2.conv2d.bias':
    # # # #         # param = param.cpu().detach().numpy()
    # # # #         print(param[0])