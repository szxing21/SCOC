# Copyright (C) 2020 Luceda Photonics

import si_fab.all as pdk
import ipkiss3.all as i3
import numpy as np
import pylab as plt

center_env = i3.Environment(wavelength=1.3)
widths = np.linspace(0.4, 1.2, 100)
neffs = []
ngs = []

for w in widths:
    tmpl = pdk.SiWireWaveguideTemplate()
    tmpl.Layout(core_width=w)
    tmpl_cm = tmpl.CircuitModel()
    neffs.append(tmpl_cm.get_n_eff(center_env))
    ngs.append(tmpl_cm.get_n_g(center_env))

fig, ax1 = plt.subplots()

ax1.plot(widths, neffs, "o-", markersize=5, linewidth=3, color="steelblue")
ax1.set_xlabel("Width [um]", fontsize=14)
ax1.set_ylabel("Effective index", color="steelblue", fontsize=14)
ax1.tick_params(axis="y", labelcolor="steelblue", labelsize=14)
ax1.tick_params(axis="x", labelcolor="black", labelsize=14)

ax2 = ax1.twinx()
ax2.plot(widths, ngs, "o-", markersize=5, linewidth=3, color="coral")
ax2.set_ylabel("Group index", color="coral", fontsize=14)
ax2.tick_params(axis="y", labelcolor="coral", labelsize=14)

fig.tight_layout()
plt.show()
