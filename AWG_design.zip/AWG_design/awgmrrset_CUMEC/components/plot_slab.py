# Copyright (C) 2020 Luceda Photonics

import si_fab.all as pdk
from si_fab_awg.all import SiSlabTemplate
import numpy as np

# Instantiate slab
slab = SiSlabTemplate()

# Visualize cross-section
slab_layout = slab.Layout()
slab_xs = slab_layout.cross_section()
slab_xs.visualize()

# Calculate and visualize modes
wavelengths = np.linspace(1.25, 1.35, 101)
slab_modes = slab.SlabModesFromCamfr(wavelengths=wavelengths)
slab_modes.visualize(wavelengths=wavelengths)
