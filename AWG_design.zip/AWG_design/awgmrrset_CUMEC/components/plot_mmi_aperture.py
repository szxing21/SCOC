# Copyright (C) 2020 Luceda Photonics

import si_fab.all as pdk
from si_fab_awg.all import SiSlabTemplate, SiRibMMIAperture
import ipkiss3.all as i3
import numpy as np

wavelengths = np.linspace(1.25, 1.35, 100)
center_wavelength = 1.3

slab_tmpl = SiSlabTemplate()
slab_tmpl.SlabModesFromCamfr(wavelengths=wavelengths)

aperture = SiRibMMIAperture(slab_template=slab_tmpl, mmi_length=9.0, wire_width=0.4)

# Layout
print("Instantiating aperture layout...\n")
aperture_lay = aperture.Layout()
aperture_lay.visualize(annotate=True)
aperture_lay.visualize_2d(process_flow=i3.TECH.VFABRICATION.PROCESS_FLOW_FEOL)

# Field model
fieldmodel = aperture.FieldModelFromCamfr()
env = i3.Environment(wavelength=center_wavelength)

# Field profile at the aperture
print("Simulating field profile at aperture...\n")
fields = fieldmodel.get_fields(mode=0, environment=env)
fields.visualize()

# Field propagated from input to the aperture
print("Simulating aperture field propagation...\n")
fields_2d = fieldmodel.get_aperture_fields2d(mode=0, environment=env)
fields_2d.visualize()

# Far field of the aperture
print("Simulating far field of the aperture...\n")
fields_ff = fieldmodel.get_far_field(mode=0, environment=env)
divergence_angle = fields_ff.divergence_angle(slab_mode="TE0", method="e_sq")
print(divergence_angle)
fields_ff.visualize()
