# Copyright (C) 2020 Luceda Photonics

import si_fab.all as pdk
import ipkiss3.all as i3
import numpy as np
import pylab as plt

TECH = i3.get_technology()

wavelengths = np.linspace(1.25, 1.35, 100)

epsilon_si = [
    TECH.MATERIALS.SILICON.get_epsilon(
        i3.Environment(
            wavelength=wavelength,
        ),
    ).real
    for wavelength in wavelengths
]

epsilon_sio2 = [
    TECH.MATERIALS.SILICON_OXIDE.get_epsilon(
        i3.Environment(
            wavelength=wavelength,
        ),
    ).real
    for wavelength in wavelengths
]

plt.subplot(211)
plt.plot(wavelengths, epsilon_si, "b-", linewidth=5)
plt.xlabel("Wavelength [um]")
plt.ylabel(r"$\epsilon_r$")
plt.title("Relative permittivity of silicon")
plt.subplot(212)
plt.plot(wavelengths, epsilon_sio2, "b-", linewidth=5)
plt.xlabel("Wavelength [um]")
plt.ylabel(r"$\epsilon_r$")
plt.title(r"Relative permittivity of SiO2")
plt.tight_layout()
plt.show()
