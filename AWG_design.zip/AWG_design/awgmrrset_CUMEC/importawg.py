from CSiP180Al import all as pdk  # noqa
from ipkiss3 import all as i3
from ipkiss3.all import START, END
from CSiP180Al.all import BP, ABSORBER
import numpy as np
import pylab as plt
class awgmrrset(i3.Circuit):
    awg = i3.ChildCellProperty()
    splitter = i3.ChildCellProperty()
    BP = i3.ChildCellProperty()
    spacing_x = i3.PositiveNumberProperty(default=300.0)
    spacing_y = i3.PositiveNumberProperty(default=127.0)
    spacing_l = i3.PositiveNumberProperty(default=4)
    spacing_m = i3.PositiveNumberProperty(default=10)
    wm = i3.PositiveNumberProperty(default=5)
    reference_y = i3.PositiveNumberProperty(default=100)
    num_ports = i3.IntProperty(default=8, doc="number of the rings")

    def _default_splitter(self):
        return pdk.RingFilterWithTerminator(ring_num=1)
    def _default_BP(self):
        return pdk.BP()
    def _default_insts(self):
        insts = {
            "awg": self.awg,
            # "mrr1": self.splitter,
            "mrr1": self.splitter,
            "mrr2": self.splitter,
            "mrr3": self.splitter,
            "mrr4": self.splitter,
            "mrr5": self.splitter,
            "mrr6": self.splitter,
            "mrr7": self.splitter,
            "mrr8": self.splitter,
            'Pad1': BP(),
            'Pad2': BP(),
            'Pad3': BP(),
            'Pad4': BP(),
            'Pad5': BP(),
            'Pad6': BP(),
            'Pad7': BP(),
            'Pad8': BP(),
            'PadG': BP(),
        }
        return insts
    def _default_specs(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y*2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        sp_m = self.spacing_m
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        tt = i3.ElectricalWireTemplate()
        tt.Layout(width=5, layer=i3.TECH.PPLAYER.M1.DRW)
        num_ports = 8
        ports = []
        # for i in range(num_ports):
        #     port = i3.OpticalPort(name="out"+str(i+1), position=(600, -30-sp_y / 4-ref_y + sp_y / 2 * (15 - i)),
        #                           angle=180,
        #                           trace_template=tt1)
        #     ports.append(port)
        # 现在，ports列表包含了port1, port2, port3...
        # port1, port2, port3, port4, port5, port6, port7, port8, port9, port10, port11, port12, port13, port14, port15
        # , port16 = ports

        specs = [
            i3.FlipH("awg"),
            i3.Place("awg", (0, 0), angle=270),
            i3.PlaceRelative("mrr1:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 7)),
            i3.PlaceRelative("mrr2:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 6)),
            i3.PlaceRelative("mrr3:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 5)),
            i3.PlaceRelative("mrr4:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 4)),
            i3.PlaceRelative("mrr5:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 3)),
            i3.PlaceRelative("mrr6:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 2)),
            i3.PlaceRelative("mrr7:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 1)),
            i3.PlaceRelative("mrr8:in_1", "awg:out1", (sp_x, -ref_y+sp_y * 0)),
            i3.FlipV(["mrr1", "mrr2", "mrr3", "mrr4", "mrr5", "mrr6", "mrr7", "mrr8"]),

            i3.ConnectManhattan(
                [
                    ("mrr1:in_1", "awg:out1")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 7), i3.H(START-sp_y * 7 + sp_l * 7)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr2:in_1", "awg:out2")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 6), i3.H(START-sp_y * 6 + sp_l * 6)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr3:in_1", "awg:out3")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 5), i3.H(START-sp_y * 5 + sp_l * 5)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr4:in_1", "awg:out4")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 4), i3.H(START-sp_y * 4 + sp_l * 4)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr5:in_1", "awg:out5")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 3), i3.H(START-sp_y * 3 + sp_l * 3)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr6:in_1", "awg:out6")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 2), i3.H(START-sp_y * 2 + sp_l * 2)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr7:in_1", "awg:out7")],
                control_points=[i3.V(START - sp_x / 2 - sp_l * 1), i3.H(START-sp_y * 1 + sp_l * 1)],
                bend_radius=10,
                trace_template=tt1
            ),
            i3.ConnectManhattan(
                [
                    ("mrr8:in_1", "awg:out8")],
                control_points=[i3.H(START)],
                bend_radius=10,
                trace_template=tt1
            ),
        ]
        specs += i3.Place("PadG:pad_M1", (650, 1800)),
        for i in range(num_ports):
            specs += i3.Place("Pad"+str(i+1)+":pad_M1", (-150+i*100, 1800)),
            specs += i3.ConnectManhattan(
                [
                    ("mrr"+str(8-i)+":elec2", "Pad"+str(i+1)+":pad_M1")],
                control_points=[i3.V(START - 50 - sp_m * (8-i)), i3.H(END - 50 - sp_m * (8-i))],
                bend_radius=10,
                trace_template=tt,
            ),
            specs += i3.ConnectManhattan(
                [
                    ("mrr" + str(8 - i) + ":elec1", "PadG:pad_M1")],
                # control_points=[i3.V(START - sp_x / 2 - sp_l * 1), i3.H(START - sp_y * 1 + sp_l * 1)],
                bend_radius=10,
                trace_template=tt,
            ),
        return specs

    def _default_exposed_ports(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y * 2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        num_ports = self.num_ports
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5)
        num_ports = 16
        ports = []
        for i in range(num_ports):
            port = i3.OpticalPort(name="out_" + str(i + 1),
                                  position=(600, -30 - sp_y / 4 - ref_y + sp_y / 2 * (num_ports -1 - i)),
                                  angle=180,
                                  trace_template=tt1)
            ports.append(port)

        # 现在，ports列表包含了port1, port2, port3...
        port1, port2, port3, port4, port5, port6, port7, port8, port9, port10, port11, port12, port13, port14, port15, port16 = ports
        exposed_ports = {
            "awg:in1": "in1",
            "awg:in2": "in2",
            "awg:in3": "in3",
            "awg:in4": "in4",
            "awg:in5": "in5",
            "awg:in6": "in6",
            "awg:in7": "in7",
            "awg:in8": "in8",
            "mrr1:out_1": "out1",
            "mrr1:out_2": "out2",
            "mrr2:out_1": "out3",
            "mrr2:out_2": "out4",
            "mrr3:out_1": "out5",
            "mrr3:out_2": "out6",
            "mrr4:out_1": "out7",
            "mrr4:out_2": "out8",
            "mrr5:out_1": "out9",
            "mrr5:out_2": "out10",
            "mrr6:out_1": "out11",
            "mrr6:out_2": "out12",
            "mrr7:out_1": "out13",
            "mrr7:out_2": "out14",
            "mrr8:out_1": "out15",
            "mrr8:out_2": "out16",
        }

        return exposed_ports
class threeringawgmrrset(i3.Circuit):
    awg = i3.ChildCellProperty()
    splitter = i3.ChildCellProperty()
    BP = i3.ChildCellProperty()
    spacing_x = i3.PositiveNumberProperty(default=300.0)
    spacing_y = i3.PositiveNumberProperty(default=127.0)
    spacing_l = i3.PositiveNumberProperty(default=4)
    spacing_m = i3.PositiveNumberProperty(default=10)
    spacing_r = i3.PositiveNumberProperty(default=150)
    spacing_p = i3.PositiveNumberProperty(default=80)
    wm = i3.PositiveNumberProperty(default=5)
    reference_y = i3.PositiveNumberProperty(default=100)
    num_ports = i3.IntProperty(default=8, doc="number of the ports")
    num_rings = i3.IntProperty(default=3, doc="number of the filters")
    def _default_splitter(self):
        return pdk.RingFilterall(ring_num=2)
    def _default_BP(self):
        return pdk.BP()
    def _default_terminator(self):
        return ABSORBER()
    def _default_insts(self):
        num_ports = self.num_ports
        num_rings = self.num_rings
        insts = {
            "awg": self.awg,
        }
        for j in range(num_rings):
            insts["PadG_" + str(j + 1)] = BP()
        for i in range(num_ports):
            for j in range(num_rings):
                insts["mrr_" + str(i + 1) + "_" + str(j+1)] = self.splitter
                insts["Pad_" + str(i + 1) + "_" + str(j+1)] = BP()
                if j == num_rings-1:
                    insts["ab_" + str(i + 1) + "_" + str(j + 1)] = ABSORBER()
        return insts

    def _default_specs(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y*2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        sp_m = self.spacing_m
        sp_r = self.spacing_r
        sp_p = self.spacing_p
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        ttm1 = i3.ElectricalWireTemplate()
        ttm1.Layout(width=5, layer=i3.TECH.PPLAYER.M1.DRW)
        ttm2 = i3.ElectricalWireTemplate()
        ttm2.Layout(width=20, layer=i3.TECH.PPLAYER.M1.DRW)
        num_ports = self.num_ports
        num_rings = self.num_rings
        specs = [i3.FlipH("awg"),
                 i3.Place("awg", (0, 0), angle=270)]
        # flipvstr = []
        for i in range(num_ports):
            for j in range(num_rings):
                if j == 0:
                    specs += i3.PlaceRelative("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1", "awg:out1",
                                              (sp_x, -ref_y + sp_y * (7-i))),
                    specs += i3.ConnectManhattan(
                        [
                            ("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1", "awg:out" + str(i + 1))],
                        control_points=[i3.V(START - sp_x / 2 - sp_l * (7 - i)),
                                        i3.H(START - sp_y * (7 - i) + sp_l * (7 - i))],
                        bend_radius=10,
                        trace_template=tt1
                    ),
                else:
                    specs += i3.PlaceRelative("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1",
                                              "mrr_" + str(i + 1) + "_" + str(j) + ":out_2",
                                              (sp_r, 0)),
                    specs += i3.ConnectManhattan(
                        [
                            ("mrr_" + str(i + 1) + "_" + str(j + 1) + ":out_1",
                             "mrr_" + str(i + 1) + "_" + str(j) + ":in_2")],
                        bend_radius=10,
                        trace_template=tt1
                    ),
                    specs += i3.ConnectManhattan(
                        [
                            ("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1",
                             "mrr_" + str(i + 1) + "_" + str(j) + ":out_2")],
                        bend_radius=10,
                        trace_template=tt1
                    ),
                if j == num_rings - 1:
                    specs += i3.PlaceRelative("ab_" + str(i + 1) + "_" + str(j + 1) + ":in",
                                              "mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_2",
                                              (1, 0), angle=180),
                    specs += i3.ConnectManhattan(
                        [("ab_" + str(i + 1) + "_" + str(j + 1) + ":in",
                          "mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_2")],
                        bend_radius=10,
                        trace_template=tt1
                    ),
        for j in range(num_rings):
            i = 8
            specs += i3.PlaceRelative("PadG_" + str(j + 1) + ":pad_M1",
                                      "mrr_" + str(1) + "_" + str(num_rings) + ":in_2",
                                      (i * sp_p + (j - num_rings) * (num_ports + 1) * sp_p,
                                       50 + sp_m * ((num_ports + 4) * num_rings)),
                                      angle=270),

        for i in range(num_ports):
            for j in range(num_rings):
                specs += i3.PlaceRelative("Pad_" + str(i + 1) + "_" + str(j + 1) + ":pad_M1",
                                          "mrr_" + str(1) + "_" + str(num_rings) + ":in_2",
                                          (i * sp_p + (j - num_rings) * (num_ports + 1) * sp_p,
                                           50 + sp_m * ((num_ports + 4) * num_rings)),
                                          angle=270),
                specs += i3.ConnectManhattan(
                    [
                        ("mrr_" + str(8 - i) + "_" + str(j + 1) + ":elec2",
                         "Pad_" + str(i + 1) + "_" + str(j + 1) + ":pad_M1")],
                    control_points=[i3.V(START - 20 - sp_m * (num_ports - i)),
                                    i3.H(END - 50 - sp_m * ((num_ports+4) * (num_rings - j) - i))],
                    bend_radius=10,
                    trace_template=ttm1,
                ),
                specs += i3.ConnectManhattan(
                    [
                        ("mrr_" + str(8 - i) + "_" + str(j + 1) +":elec1", "PadG_" + str(j + 1) + ":pad_M1")],
                    control_points=[i3.V(START), i3.H(END - 50 - sp_m * ((num_ports+4) * (num_rings - 1 - j) + 2.5))],
                    bend_radius=10,
                    trace_template=ttm2,
                ),
        return specs

    def _default_exposed_ports(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y * 2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        num_ports = self.num_ports
        num_rings = self.num_rings
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5)
        exposed_ports = {}
        for i in range(num_ports):
            j = num_rings-1
            exposed_ports["mrr_" + str(i + 1) + "_" + str(j + 1) + ":out_2"] = "out" + str(2 * i + 2)
            exposed_ports["awg:in"+str(i+1)] = "in" + str(i + 1)
            j = 0
            exposed_ports["mrr_" + str(i + 1) + "_" + str(j + 1) + ":out_1"] = "out" + str(2 * i + 1)
        return exposed_ports