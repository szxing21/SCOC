# Copyright (C) 2020 Luceda Photonics

from ipkiss3 import all as i3
from picazzo3.container.fanout_ports import FanoutPorts
import os
import CSiP180Al.all as pdk
from picazzo3.container.iofibcoup import IoFibcoup


def finalize_awg(awg, plot=True, die_width=3000.0, channel_spacing=100, fpr_alpha_factor=1.6, save_dir=None, tag=""):
    """Custom function to finalize an AWG design, mostly for DRC fixing and routing.
    If you make an AWG, you should write one of your own.
    Parameters are the things you want to vary as well as options to control whether you
    plot and where you save your data.

    Parameters
    ----------
    awg: i3.PCell
         Input AWG cell
    plot : bool, default: True, optional
           If true the finilized awg is plotted
    die_width: float, default: 3000.0, optional
               Width of the die
    save_dir : str, default: None, optional
               If specified, a GDSII file is saved in this directory
    tag: str, optional
         String used to give a name to saved files
    channel_spacing:
    fpr_alpha_factor:
    Returns
    -------
    awg_block: i3.PCell
               Finalized AWG block
    """

    # Fix design rules violations
    # Two types of violations may occur in the AWG: acute (sharp) angles and snapping errors.
    # We use get_stub_elements and flat_copy to fix these.
    print("Fixing design rules violations...\n")
    awg_layout = awg.get_default_view(i3.LayoutView)
    awg_netlist = awg.get_default_view(i3.NetlistView)
    awg_circuit = awg.get_default_view(i3.CircuitModelView)

    # We look for acute angles in the SHALLOW layer, typically caused by two apertures that are close together.
    elems_add, elems_subt = i3.get_stub_elements(
        layout=awg_layout,
        angle_threshold=0,
        # layers=[i3.TECH.PPLAYER.SI, i3.TECH.PPLAYER.SHALLOW],
        grow_amount=0.2,
    )

    # Wrap in a cell with a clean layout
    awg_clean_layout = awg_layout.layout.flat_copy() + elems_add
    awg_clean = i3.EmptyCell(name="awg_clean")
    awg_clean.Layout(layout=awg_clean_layout, ports=awg_layout.ports)
    awg_clean.Netlist(terms=awg_netlist.terms)
    # awg_clean.CircuitModel(model=awg_circuit.model)
    ports = [p for p in awg_layout.ports if "out" in p.name]

    # Fanout ports to horizontal on a regular pitch
    wg_tmpl = pdk.StripWaveguideTemplate()
    wg_tmpl.Layout(core_width=0.5, cladding_width=6)

    y_spacing1 = 4
    y_spacing0 = 4
    y_spacing3 = 127
    refdes3 = 150
    targdes4 = 170
    bend_radius = 10
    awg_routed01 = FanoutPorts(
        name="routed_awg01",
        contents=awg_clean,
        trace_template=wg_tmpl,
        port_labels=["in" + str(cnt) for cnt in range(1, 9)],
    )
    awg_routed01.Layout(
        output_direction=i3.DIRECTION.SOUTH,
        bend_radius=bend_radius,
        max_s_bend_angle=90.0,
        spacing=y_spacing0,
        target_coordinate=-60.0,
        reference_coordinate=(awg_layout.ports["in4"].x+awg_layout.ports["in5"].x)/2-3.5*y_spacing0,
    )
    awg_routed02 = FanoutPorts(
        name="routed_awg02",
        contents=awg_routed01,
        trace_template=wg_tmpl,
        port_labels=["in" + str(cnt) for cnt in range(8, 0, -1)],
    )
    awg_routed02.Layout(
        output_direction=i3.DIRECTION.WEST,
        bend_radius=bend_radius,
        max_s_bend_angle=90.0,
        spacing=y_spacing1,
        align_outputs=0,
        target_coordinate=-50.0,
        reference_coordinate=awg_layout.ports["in1"].y - 100,
    )

    awg_routed03 = FanoutPorts(
        name="routed_awg03",
        contents=awg_routed02,
        trace_template=wg_tmpl,
        port_labels=["in" + str(cnt) for cnt in range(7, 0, -1)],
    )
    awg_routed03.Layout(
        output_direction=i3.DIRECTION.NORTH,
        bend_radius=bend_radius,
        max_s_bend_angle=90.0,
        spacing=y_spacing1,
        target_coordinate=-60.0,
        reference_coordinate=awg_layout.ports["in1"].x-refdes3+y_spacing1,
    )

    awg_routed04 = FanoutPorts(
        name="routed_awg04",
        contents=awg_routed03,
        trace_template=wg_tmpl,
        port_labels=["in" + str(cnt) for cnt in range(8, 0, -1)],
    )
    awg_routed04.Layout(
        output_direction=i3.DIRECTION.WEST,
        bend_radius=bend_radius,
        max_s_bend_angle=90.0,
        spacing=y_spacing3,
        target_coordinate=-targdes4,
        reference_coordinate=awg_layout.ports["in1"].y - 100,
    )

    awg_routed14 = FanoutPorts(
        name="routed_awg14",
        contents=awg_routed04,
        trace_template=wg_tmpl,
        port_labels=["out" + str(cnt) for cnt in range(16, 0, -1)],
    )
    awg_routed_layout1 = awg_routed14.Layout(
        output_direction=i3.DIRECTION.EAST,
        bend_radius=bend_radius,
        max_s_bend_angle=90.0,
        spacing=y_spacing3,
        target_coordinate=(awg_layout.ports["out1"].x+30),
        reference_coordinate=awg_layout.ports["in1"].y - 100,
    )
    # awg_routed_layout1.visualize(annotate=True)
    elems_add1, elems_subt1 = i3.get_stub_elements(
        layout=awg_routed_layout1,
        angle_threshold=0,
        # stub_width=0.1,
        # layers=[i3.TECH.PPLAYER.SI, i3.TECH.PPLAYER.SHALLOW],
        grow_amount=0.2,
    )
    #
    awg_block_layout1 = awg_routed_layout1.layout+elems_add1
    # i3.LayoutCell().Layout(elements=awg_block_layout1).visualize(annotate=True)
    awg_routed14.Layout(layout=awg_block_layout1,
                        output_direction=i3.DIRECTION.EAST,
                        bend_radius=bend_radius,
                        max_s_bend_angle=90.0,
                        spacing=y_spacing3,
                        target_coordinate=(awg_layout.ports["out1"].x + 30),
                        reference_coordinate=awg_layout.ports["in1"].y - 100,)
    # Define fiber coupler adapter
    class IoFibcoup1550(IoFibcoup):
        def _default_trace_template(self):
            return wg_tmpl

        def _default_fiber_coupler(self):
            return pdk.GC_TE_1550()

    # Make an AWG test structure
    print("Making AWG test structure...\n")
    awg_block = i3.IoColumn(name="awg_test"+str(channel_spacing)+"G"+str(fpr_alpha_factor), adapter=IoFibcoup1550)
    awg_block_layout = awg_block.Layout(south_east=(1200, 0.0), y_spacing=127.0)
    awg_block.add_blocktitle("AWG")
    awg_block.add_align(trace_template=wg_tmpl)
    awg_block.add_emptyline(0)
    awg_block.add(
        awg_routed14,
        bend_radius=10.0,
        max_s_bend_angle=90.0,
        relative_offset=(0.0, 0),
    )

    # print("relative_offset y value:", awg_routed_layout.ports["in1"].y - awg_routed_layout.ports["out1"].y)
    # Plotting and writing to gds
    if plot:
        awg_block_layout.visualize(annotate=True)

    if save_dir:
        gds_path = os.path.abspath(os.path.join(save_dir, "awg_{}.gds".format(tag)))
        awg_block_layout.write_gdsii(gds_path)
        print("{} written.".format(gds_path))

    return awg_block
