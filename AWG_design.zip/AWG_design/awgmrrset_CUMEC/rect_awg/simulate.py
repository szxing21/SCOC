# Copyright (C) 2020 Luceda Photonics

from ipkiss3 import all as i3
import os


def simulate_awg(awg, wavelengths, save_dir=None, tag=""):
    """Custom function to simulate an AWG. If you make an AWG, you should write one of your own.
    Parameters are the awg cell you want to simulate and things that control your simulation as well as
    parameters that control where you save your data.

    Parameters
    ----------
    awg : i3.Pcell
          AWG PCell
    wavelengths: ndarray
                 Simulation wavelengths
    save_dir: str, default: None, optional
              If specified, a GDSII file is saved in this directory
    tag: str, optional
         String used to give a name to saved files

    Returns
    -------
    awg_s:
           S-matrix of the simulated AWG

    """
    cwdm_awg_cm = awg.get_default_view(i3.CircuitModelView)
    print("Simulating AWG...\n")
    awg_s = cwdm_awg_cm.get_smatrix(wavelengths)
    if save_dir:
        smatrix_path = os.path.join(save_dir, "smatrix_{}.s{}p".format(tag, awg_s.data.shape[0]))
        awg_s.to_touchstone(smatrix_path)
        print("{} written".format(smatrix_path))
    return awg_s
