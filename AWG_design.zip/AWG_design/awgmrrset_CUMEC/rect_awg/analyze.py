# Copyright (C) 2020 Luceda Photonics

from awg_designer import all as awg
from ipkiss3 import all as i3
import numpy as np
import pylab as plt
import json
import os


def analyze_awg(awg_s, peak_threshold=-10.0, plot=True, save_dir=None, tag=""):
    """Custom AWG analysis function. If you make an AWG, you should write an analysis function of your own.
    The goal of the analyze_awg function is to answer the question: how does the AWG perform
    according to my specs? In an analysis function you define the specs and check the behaviour
    of the AWG according to those specs using helper functions provided in the IPKISS AWG Designer.
    The parameters are the things you want to vary as well as options to control whether you
    plot and where you save your data.

    Parameters
    ----------
    awg_s: SMatrix1DSweep
        S-matrix of the AWG
    peak_threshold: float, default: -10.0, optional
        The power threshold for peak detection (in dB)
    plot: bool, default: True, optional
        If true, the spectrum is plotted
    save_dir: str, default: None, optional
        If specified, a GDSII file is saved in this directory
    tag: str, optional
        String used to give a name to saved files

    Returns
    ------
    report: dict
        Dictionary containing analysis specs
    """

    # Specs
    channel_freq = np.array([192714.48903226, 192714.48903226, 192914.48903226, 192914.48903226, 193114.48903226,
                             193114.48903226, 193314.48903226, 193314.48903226, 193514.48903226, 193514.48903226,
                             193714.48903226, 193714.48903226, 193914.48903226, 193914.48903226, 194114.48903226,
                             194114.48903226])
    channel_wav = np.flip(awg.frequency_to_wavelength(channel_freq))
    channel_width = 0.0016 #10e-4
    output_ports = ["out{}".format(p + 1) for p in range(len(channel_wav))]

    # Initialize spectrum analyzer
    analyzer = i3.SpectrumAnalyzer(
        smatrix=awg_s,
        input_port_mode="in1:0",
        output_port_modes=output_ports,
        dB=True,
        peak_threshold=peak_threshold,
    )
    analyzer = analyzer.trim(
        (
            min(channel_wav) - channel_width/2,
            max(channel_wav) + channel_width,
        )
    )

    # Measurements
    peaks = analyzer.peaks()
    peak_wavelengths = [peak["wavelength"][0] for peak in peaks.values()]
    # peak_wavelengths = peak_wavelengths[::2]
    peak_error = np.abs(channel_wav - peak_wavelengths)
    analyzer.visualize(title=tag.capitalize(), show=0)
    bands = analyzer.width_passbands(channel_width)
    insertion_loss = list(analyzer.min_insertion_losses(bands=bands).values())
    cross_talk_near = list(analyzer.near_crosstalk(bands=bands).values())
    cross_talk_far = list(analyzer.far_crosstalk(bands=bands).values())
    passbands_3dB = list(analyzer.cutoff_passbands(cutoff=-3.0).values())

    # Create report
    report = dict()
    band_values = list(bands.values())
    for cnt, port in enumerate(output_ports):
        channel_report = {
            "peak_expected": channel_wav[cnt],
            "peak_simulated": peak_wavelengths[cnt],
            "peak_error": peak_error[cnt],
            "band": band_values[cnt][0],
            "insertion_loss": insertion_loss[cnt][0],
            "cross_talk": cross_talk_far[cnt] - insertion_loss[cnt][0],
            # "cross_talk_nn": cross_talk_near[cnt] - insertion_loss[cnt][0],
            "passbands_3dB": passbands_3dB[cnt],
        }
        report[port] = channel_report

    if save_dir:
        def serialize_ndarray(obj):
            return obj.tolist() if isinstance(obj, np.ndarray) else obj

        report_path = os.path.join(save_dir, "report_{}.json".format(tag))
        with open(report_path, "w") as f:
            json.dump(report, f, sort_keys=True, default=serialize_ndarray, indent=0)
        print("{} written".format(report_path))

    # Plot spectrum and specified channels
    fig = analyzer.visualize(title=tag.capitalize(), show=0)
    for spec_wavelength in channel_wav:
        plt.axvline(x=spec_wavelength)
    # plt.show()
    #
    # for passband in passbands_3dB:
    #     plt.axvline(x=passband[0][0], color="k", linestyle=":")
    #     plt.axvline(x=passband[0][1], color="k", linestyle=":")

    png_path = os.path.join(save_dir, "spectrum_{}.png".format(tag))
    fig.savefig(os.path.join(save_dir, png_path), bbox_inches="tight")
    print("{} written".format(png_path))

    if plot:
        # Plot transmission spectrum
        plt.show()
    plt.close(fig)
    return report
