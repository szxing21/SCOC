# Copyright (C) 2020 Luceda Photonics

from ipkiss3 import all as i3
import re


def simulate_opa(
    cell,
    dv_start=0.0,
    dv_end=1.0,
    nsteps=50,
    center_wavelength=1.5,
    debug=False,
):
    """Simulation recipe to simulate an optical phased array (OPA) by sweeping the bias voltage.

    Parameters
    ----------
    cell : i3.PCell
        OPA PCell to be simulated
    dv_start : float
        Linear difference in voltage at the beginning of the sweep
    dv_end : float
        Linear difference in voltage at the end of the sweep
    nsteps : int
        Number of steps to be used in the voltage sweep
    center_wavelength : float
        Center wavelength
    debug : bool
        If True, the simulation is run in debug mode

    Returns
    -------
    Time response

    """
    dt = 1
    t0 = 0
    t1 = nsteps

    # Get the number of output ports
    dut_lv = cell.get_default_view(i3.LayoutView)
    port_list_out_sorted = [p.name for p in dut_lv.ports.y_sorted() if re.search("(out)", p.name)]
    n_outs = len(port_list_out_sorted)

    # Define the optical source at the input.
    # Note, FunctionExcitation is a PCell.
    # It's essentially a component that is placed in the circuit and sends a signal into the chip
    # through its output port.
    #
    # Using the argument port_domain, you can specify whether to input an optical or electrical signal,
    # excitation_function provides the input signal in terms of time.

    optical_in = i3.FunctionExcitation(
        port_domain=i3.OpticalDomain,
        excitation_function=lambda t: 1.0,
    )

    # Use nested functions to generate a function that defines the distribution
    # of the electrical signal, in volts, in terms of time.
    def get_source(v_start, v_end):
        def linear_ramp(t):
            return v_end * (t / t1) ** 0.5 + v_start * ((t1 - t) / t1) ** 0.5

        return linear_ramp

    # Define the child cells and links (direct connections)
    child_cells = {
        "DUT": cell,
        "optical_in": optical_in,
    }
    links = [("optical_in:out", "DUT:in")]

    for cnt in range(n_outs):

        # Define sources of electrical signals at electrical ports
        child_cells["v{}".format(cnt)] = i3.FunctionExcitation(
            port_domain=i3.ElectricalDomain,
            excitation_function=get_source(cnt * dv_start, cnt * dv_end),
        )
        links.append(("v{}:out".format(cnt), "DUT:hti{}".format(cnt)))

        child_cells["out{}".format(cnt)] = i3.Probe(port_domain=i3.OpticalDomain)
        links.append(("out{}:in".format(cnt), "DUT:out{}".format(cnt)))

    # Create a test bench by connecting the sources to the ports of the circuit using ConnectComponent
    testbench = i3.ConnectComponents(
        child_cells=child_cells,
        links=links,
    )

    # Now we simulate the test bench and return the time response.
    print("Simulating circuit between {} and {} with step {} - nsteps {}".format(t0, t1, dt, nsteps))

    cm = testbench.CircuitModel()
    results = cm.get_time_response(
        t0=t0,
        t1=t1,
        dt=dt,
        center_wavelength=center_wavelength,
        debug=debug,
    )

    return results
