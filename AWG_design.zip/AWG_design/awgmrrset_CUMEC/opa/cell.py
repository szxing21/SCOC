# Copyright (C) 2020 Luceda Photonics

"""In this file we create an optical phased array (OPA) with heaters connected via electrical ports.

The OPA consists of a splitter tree with heaters connected to each of the outputs.
The heaters are controlled electrically and are connected to contact pads via electrical wiring.

Note: make sure to mark '/libraries/pteam_library_si_fab/ipkiss' as sources root (right-click on the folder in PyCharm).
"""

from CSiP180Al import all as pdk
# from pteam_library_si_fab import all as pteam_lib
from ipkiss3 import all as i3
from ipkiss3.pcell.netlist.instance import InstanceTerm
import copy


class OPA(i3.Circuit):
    """Class for an optical phased array (OPA) composed of a splitter tree and an array of heaters."""

    _name_prefix = "OPA"

    heater = i3.ChildCellProperty(doc="Heater PCell used at the outputs of the splitter tree")
    splitter = i3.ChildCellProperty(doc="Splitter PCell used in the splitter tree")
    levels = i3.PositiveIntProperty(default=4, doc="Number of levels in the splitter tree")
    spacing_y = i3.PositiveNumberProperty(
        default=50.0,
        doc="Vertical spacing between the levels of the splitter tree",
    )
    spacing_x = i3.PositiveNumberProperty(
        default=100.0,
        doc="Horizontal spacing between the splitters in the last level",
    )

    def _get_n_outputs(self):
        return 2**self.levels

    def _default_heater(self):
        # By default, the heater is a 1 mm-long heated waveguide
        ht = pdk.HeatedWaveguide()
        ht.Layout(shape=[(0.0, 0.0), (1000.0, 0.0)])
        return ht

    def _default_splitter(self):
        return pdk.MMI1x2Optimized1550()

    def _default_insts(self):
        insts = dict()
        # Create a splitter tree, then add a heater at each output
        splitter_tree = pteam_lib.SplitterTree(
            levels=self.levels,
            splitter=self.splitter,
            spacing_y=2 * self.spacing_y,
        )
        insts["tree"] = splitter_tree
        for cnt in range(self._get_n_outputs()):
            insts["ht{}".format(cnt)] = self.heater
        return insts

    def _default_specs(self):
        # Position the heaters and connect them to the splitter tree
        specs = []
        east = self.insts["tree"].get_default_view(i3.LayoutView).size_info().east
        n_outputs = self._get_n_outputs()
        for n_out in range(n_outputs):
            specs += [
                i3.Place(
                    "ht{}".format(n_out),
                    (east + self.spacing_x, (n_out - (n_outputs - 1) / 2.0) * self.spacing_y),
                ),
                i3.ConnectManhattan(
                    "ht{}:in".format(n_out),
                    "tree:out{}".format(n_out + 1),
                ),
            ]
        return specs

    def _default_exposed_ports(self):
        # Set the names of the electrical ports
        exposed_ports = dict()
        exposed_ports["tree:in"] = "in"
        for n_out in range(self._get_n_outputs()):
            exposed_ports["ht{}:elec1".format(n_out)] = "hti{}".format(n_out)
            exposed_ports["ht{}:elec2".format(n_out)] = "hto{}".format(n_out)
            exposed_ports["ht{}:out".format(n_out)] = "out{}".format(n_out)
        return exposed_ports


class RoutedOPA(i3.PCell):
    """Optical phased array (OPA) whose heaters are electrically connected to metal contact pads via electrical wires.
    In this example, the device under test (DUT) is the OPA, but the code has been written in such a way that
    it can be generalised to other PCells with electrical ports.
    """

    # 1. We define the properties of the PCell.
    dut = i3.ChildCellProperty(doc="The device under test, in this case the OPA")
    fgc = i3.ChildCellProperty(doc="Fiber grating couplers PCell")
    bondpad = i3.ChildCellProperty(doc="Bondpads PCell")
    bond_pads_spacing = i3.PositiveNumberProperty(default=100.0, doc="The horizontal distance between the contact pads")
    wire_spacing = i3.PositiveNumberProperty(default=10.0, doc="The spacing between the electrical wires")
    length_of_out_wg = i3.PositiveNumberProperty(default=300.0, doc="Length of output waveguide")
    length_of_in_wg = i3.PositiveNumberProperty(default=300.0, doc="Length of output waveguide")

    def _default_dut(self):
        return OPA(name=self.name + "_opa")

    def _default_fgc(self):
        return pdk.GC_TE_1550()

    def _default_bondpad(self):
        return pdk.BP()

    class Layout(i3.LayoutView):
        def _generate_instances(self, insts):

            # 2. We define the instances that form our circuit.
            # The instances of our circuit are the DUT (the OPA), the grating couplers and the contact pads
            instances = {"DUT": self.dut}
            dut_lo = self.dut
            for port in dut_lo.ports.optical_ports:
                instances["gr_{}".format(port)] = self.fgc
            for port in (p for p in dut_lo.ports if p.domain is i3.ElectricalDomain):
                instances["bp_{}".format(port)] = self.bondpad

            # 3. We define placement and routing specifications.

            # Useful parameters that we will use in our code:
            bp_spacing = self.bond_pads_spacing
            wire_spacing = self.wire_spacing
            bp_height = abs(self.bondpad.size_info().north - self.bondpad.size_info().south)
            height = dut_lo.size_info().north

            # Sorted list of output optical ports of the DUT
            port_list_out_sorted = [p.name for p in dut_lo.east_ports.y_sorted()]

            # Sorted list of electrical ports of the DUT
            el_in_sorted = [p.name for p in dut_lo.ports.y_sorted() if "hti" in p.name]
            el_out_sorted = [p.name for p in dut_lo.ports.y_sorted_backward() if "hto" in p.name]
            n_el_ports = len(el_in_sorted) + len(el_out_sorted)
            bp_position_y = height + 2 * bp_spacing + (n_el_ports // 2) * wire_spacing

            # Place the DUT (splitter tree) at the origin
            specs = [i3.Place("DUT", (0, 0))]

            # Place the grating couplers relative to the input and output ports of the DUT
            specs += [i3.PlaceRelative("gr_in:out", "DUT:in", (-self.length_of_in_wg, 0), angle=0.0)]
            specs += [
                i3.PlaceRelative(
                    "gr_{}:out".format(p),
                    "DUT:{}".format(p),
                    (self.length_of_out_wg, 0),
                    angle=180.0,
                )
                for p in dut_lo.ports
                if "out" in p.name
            ]

            # Place the bondpads
            specs += [
                i3.Place(
                    "bp_{}:m1".format(p),
                    (idx * bp_spacing, bp_position_y),
                )
                for idx, p in enumerate(el_in_sorted + el_out_sorted)
            ]

            # Connect the output optical ports all to output grating couplers
            specs += [
                i3.ConnectManhattan(
                    "DUT:{}".format(p),
                    "gr_{}:out".format(p),
                )
                for p in port_list_out_sorted
            ]

            # Connect the input optical port to the input grating coupler
            specs += [
                i3.ConnectManhattan(
                    "DUT:in",
                    "gr_in:out",
                )
            ]

            # Define trace templates for the electrical routing
            tt = i3.ElectricalWireTemplate()
            tt.Layout(width=4.0, layer=i3.TECH.PPLAYER.M1.DRW)

            cnt, cnt_x = 1, 0

            # Loop over each electrical port to provide the route to the contact pads
            for idx, p in enumerate(el_in_sorted + el_out_sorted):
                cnt_x = cnt_x + 1
                pos_v_line = dut_lo.ports[p].x - (n_el_ports // 2 - cnt_x) * wire_spacing
                if pos_v_line > idx * bp_spacing:
                    cnt = cnt - 1
                else:
                    cnt = cnt + 1

                # Angle in the electrical ports defines the starting angle of the manhattan route
                if n_el_ports // 2 > cnt_x:
                    start_port = dut_lo.ports[p].modified_copy(angle=180)
                elif n_el_ports // 2 == cnt_x:
                    start_port = dut_lo.ports[p].modified_copy(angle=90)
                else:
                    start_port = dut_lo.ports[p].modified_copy(angle=0)

                bp_position = (idx * bp_spacing, bp_position_y)
                end_port = i3.ElectricalPort(position=bp_position, angle=-90, name=p)
                specs += [
                    i3.ConnectManhattan(
                        start_port,
                        end_port,
                        "DUT_{}_to_bp_{}_m1".format(p, p),
                        control_points=[
                            i3.V(pos_v_line),
                            i3.H(i3.END - 2 * bp_height - cnt * wire_spacing),
                        ],
                        trace_template=tt,
                        bend_radius=0.1,
                    )
                ]
            insts += i3.place_and_route(instances, specs)
            return insts

        def _generate_ports(self, ports):
            exposed_ports = dict()
            exposed_ports["gr_in:vertical_in"] = "in"
            for cnt in range(self.dut.cell._get_n_outputs()):
                exposed_ports["gr_out{}:vertical_in".format(cnt)] = "out{}".format(cnt)
                exposed_ports["DUT:hti{}".format(cnt)] = "hti{}".format(cnt)
                exposed_ports["DUT:hto{}".format(cnt)] = "hto{}".format(cnt)
            ports += i3.expose_ports(
                self.instances,
                exposed_ports,
                optical="explicit",
                electrical="explicit",
            )
            return ports

    class CircuitModel(i3.CircuitModelView):
        def _generate_model(self):
            return i3.HierarchicalModel.from_netlistview(self.netlist_view)

    class Netlist(i3.NetlistFromLayout):
        def _generate_netlist(self, netlist):
            # extract from layout
            netlist = super(RoutedOPA.Netlist, self)._generate_netlist(self)
            # remove electrical connections and components which were extracted but we can't use
            instances = copy.copy(netlist.instances)
            for instname in instances:
                instref = netlist.instances[instname].reference
                if isinstance(instref.cell, (pdk.BONDPAD_5050, i3.ElectricalWire)):
                    netlist.instances.pop(instname)
                    remove_nets = set()
                    for net in netlist.nets.values():
                        for term in net.terms:
                            if isinstance(term, InstanceTerm) and term.instance.name == instname:
                                remove_nets.add(net.name)
                    for net_name in remove_nets:
                        netlist.nets.pop(net_name)
            return netlist


class TwoSidesRoutedOPA(i3.PCell):
    """Optical phased array (OPA) whose heaters are electrically connected to metal contact pads via electrical wires.

    In this example, the device under test (DUT) is the OPA, but the code has been written in such a way that
    it can be generalised to other PCells with electrical ports.
    """

    # 1. We define the properties of the PCell.
    dut = i3.ChildCellProperty(doc="The device under test, in this case the OPA")
    fgc = i3.ChildCellProperty(doc="Fiber grating couplers PCell")
    bondpad = i3.ChildCellProperty(doc="Bondpads PCell")
    bond_pads_spacing = i3.PositiveNumberProperty(default=100.0, doc="Horizontal distance between the contact pads")
    wire_spacing = i3.PositiveNumberProperty(default=10.0, doc="Spacing between the electrical wires")
    length_of_out_wg = i3.PositiveNumberProperty(default=300.0, doc="Length of output waveguide")
    length_of_in_wg = i3.PositiveNumberProperty(default=300.0, doc="Length of output waveguide")

    def _default_dut(self):
        return OPA(name=self.name + "_opa")

    def _default_fgc(self):
        return pdk.FC_TE_1550()

    def _default_bondpad(self):
        return pdk.BONDPAD_5050()

    class Layout(i3.LayoutView):
        def _generate_instances(self, insts):

            # 2. We define the instances that form our circuit.
            # The instances of our circuit are the DUT (the OPA), the grating couplers and the contact pads
            instances = {"DUT": self.dut}
            dut_lo = self.dut
            for p in dut_lo.ports:
                if p.domain is i3.OpticalDomain:
                    instances["gr_{}".format(p)] = self.fgc
                elif p.domain is i3.ElectricalDomain and "hti" in p.name:
                    instances["bp_n_{}".format(p)] = self.bondpad
                else:
                    instances["bp_s_{}".format(p)] = self.bondpad

            # 3. We define placement and routing specifications.

            # Useful parameters that we will use in our code:
            bp_spacing = self.bond_pads_spacing
            wire_spacing = self.wire_spacing
            bp_height = abs(self.bondpad.size_info().north - self.bondpad.size_info().south)
            height = dut_lo.size_info().north

            # Sorted list of output optical ports of the DUT
            port_list_out_sorted = [p.name for p in dut_lo.east_ports.y_sorted()]

            # Sorted list of electrical ports of the DUT
            el_in_sorted = [p.name for p in dut_lo.ports.y_sorted() if "hti" in p.name]
            el_out_sorted = [p.name for p in dut_lo.ports.y_sorted_backward() if "hto" in p.name]
            n_el_ports = len(el_in_sorted + el_out_sorted)
            bp_position_y = height + 2 * bp_spacing + len(el_in_sorted + el_out_sorted) * wire_spacing

            # Place the DUT (splitter tree) at the origin
            # Place the input grating couplers relative to the input ports of the DUT
            specs = [
                i3.Place("DUT", (0, 0)),
                i3.PlaceRelative("gr_in:out", "DUT:in", (-self.length_of_in_wg, 0), angle=0.0),
            ]

            # Place the output grating couplers relative to the output ports of the DUT
            specs += [
                i3.PlaceRelative(
                    "gr_{}:out".format(p),
                    "DUT:{}".format(p),
                    (self.length_of_out_wg, 0),
                    angle=180.0,
                )
                for p in dut_lo.ports
                if "out" in p.name
            ]

            # Place the bondpads
            specs += [
                i3.Place(
                    "bp_n_{}:m1".format(p),
                    (idx * bp_spacing, bp_position_y),
                )
                for idx, p in enumerate(el_in_sorted)
            ]
            specs += [
                i3.Place(
                    "bp_s_{}:m1".format(p),
                    (idx * bp_spacing, -bp_position_y),
                )
                for idx, p in enumerate(el_out_sorted)
            ]

            # Connect the output optical ports all to output grating couplers
            specs += [
                i3.ConnectManhattan(
                    "DUT:{}".format(p),
                    "gr_{}:out".format(p),
                )
                for p in port_list_out_sorted
            ]

            # Connect the input optical port to the input grating coupler
            specs += [
                i3.ConnectManhattan("DUT:in", "gr_in:out"),
            ]

            # Define trace templates for the electrical routing
            tt = i3.ElectricalWireTemplate()
            tt.Layout(width=4.0, layer=i3.TECH.PPLAYER.M1)

            cnt_south, cnt_north, cnt_x = n_el_ports // 2, 1, 0

            # Loop over each electrical port to provide the route to the contact pads
            for idx, (el_in, el_out) in enumerate(zip(el_in_sorted, el_out_sorted)):
                cnt_x = cnt_x + 1

                # ROUTING NORTH

                pos_v_line_north = dut_lo.ports[el_in].x - (n_el_ports // 2 - cnt_x) * wire_spacing
                if pos_v_line_north > idx * bp_spacing:
                    cnt_north = cnt_north - 1
                else:
                    cnt_north = cnt_north + 1

                # Angle in the electrical ports defines the starting angle of the manhattan route
                if n_el_ports / 2 > cnt_x:
                    start_port_north = dut_lo.ports[el_in].modified_copy(angle=180)
                elif n_el_ports / 2 == cnt_x:
                    start_port_north = dut_lo.ports[el_in].modified_copy(angle=90)
                else:
                    start_port_north = dut_lo.ports[el_in].modified_copy(angle=0)

                bp_position_north = (idx * bp_spacing, bp_position_y)
                end_port_north = i3.ElectricalPort(position=bp_position_north, angle=-90, name=el_in)

                specs += [
                    i3.ConnectManhattan(
                        start_port_north,
                        end_port_north,
                        "DUT_{}_to_bp_{}_n_m1".format(el_in, el_in),
                        control_points=[
                            i3.V(pos_v_line_north),
                            i3.H(i3.END - 2 * bp_height - wire_spacing * cnt_north),
                        ],
                        trace_template=tt,
                        bend_radius=0.1,
                    )
                ]

                # ROUTING SOUTH

                pos_v_line_south = dut_lo.ports[el_out].x + bp_height + (n_el_ports / 2 - cnt_x) * wire_spacing
                if pos_v_line_south < (n_el_ports / 2 - idx) * bp_spacing:
                    cnt_south = cnt_south - 1
                else:
                    cnt_south = cnt_south + 1
                bp_position_south = ((n_el_ports / 2 - idx - 1) * bp_spacing, -bp_position_y)
                start_port_south = dut_lo.ports[el_out].modified_copy(angle=0)
                end_port_south = i3.ElectricalPort(position=bp_position_south, angle=90, name=el_out)

                specs += [
                    i3.ConnectManhattan(
                        start_port_south,
                        end_port_south,
                        "DUT_{}_to_bp_{}_m1_s".format(el_out, el_out),
                        control_points=[
                            i3.V(pos_v_line_south),
                            i3.H(i3.END + 2 * bp_height + cnt_south * wire_spacing),
                        ],
                        trace_template=tt,
                        bend_radius=0.1,
                    )
                ]

            insts += i3.place_and_route(instances, specs)

            return insts

        def _generate_ports(self, ports):
            exposed_ports = dict()
            exposed_ports["gr_in:vertical_in"] = "in"
            for n_out in range(self.dut.cell._get_n_outputs()):
                exposed_ports["gr_out{}:vertical_in".format(n_out)] = "out{}".format(n_out)
                exposed_ports["DUT:hti{}".format(n_out)] = "hti{}".format(n_out)
                exposed_ports["DUT:hto{}".format(n_out)] = "hto{}".format(n_out)
            ports += i3.expose_ports(
                self.instances,
                exposed_ports,
                optical="explicit",
                electrical="explicit",
            )
            return ports

    class CircuitModel(i3.CircuitModelView):
        def _generate_model(self):
            return i3.HierarchicalModel.from_netlistview(self.netlist_view)

    class Netlist(i3.NetlistFromLayout):
        def _generate_netlist(self, netlist):
            # extract from layout
            netlist = super(TwoSidesRoutedOPA.Netlist, self)._generate_netlist(self)
            # remove electrical connections and components which were extracted but we can't use
            instances = copy.copy(netlist.instances)
            for instname in instances:
                instref = netlist.instances[instname].reference
                if isinstance(instref.cell, (pdk.BONDPAD_5050, i3.ElectricalWire)):
                    netlist.instances.pop(instname)
                    remove_nets = set()
                    for net in netlist.nets.values():
                        for term in net.terms:
                            if isinstance(term, InstanceTerm) and term.instance.name == instname:
                                remove_nets.add(net.name)
                    for net_name in remove_nets:
                        netlist.nets.pop(net_name)
            return netlist
