from CSiP180Al import all as pdk  # noqa
from opa.cell import RoutedOPA
from ipkiss3 import all as i3
from ipkiss3.all import START, END
import numpy as np
import pylab as plt
ring = pdk.RingFilterWithTerminator(ring_num=1)
ring_layout = ring.Layout()
ring_layout.visualize(annotate=True)
ring_layout.write_gdsii("ringfilter.gds")

