# Copyright (C) 2020 Luceda Photonics

import CSiP180Al.all as pdk
import ipkiss3.all as i3
import numpy as np
import os

from rect_awg.generate_new import generate_awg
from rect_awg.simulate import simulate_awg
from rect_awg.finalize import finalize_awg
from rect_awg.analyze_final import analyze_final
from rect_awg.analyze import analyze_awg
from importawg import awgmrrset, threeringawgmrrset
# Actions
generate = 1
simulate = 0
analyze = 0
finalize = 1
plot = 0

# Specifications
n_channels = 8
channel_spacing = 200  # GHz
wg_width = 0.5
fsr = n_channels * channel_spacing

cslist=[100]
faflist=[1]
for cs in cslist:
    for faf in faflist:

        # twl = 2
        # oas = 4
        # faf = 1.6
        channel_spacing = cs
        fpr_alpha_factor = faf
        # Creating a folder for results
        this_dir = os.path.abspath(os.path.dirname(__file__))
        designs_dir = os.path.join(this_dir, "designs")
        if not os.path.exists(designs_dir):
            os.mkdir(designs_dir)
        save_dir = os.path.join(designs_dir, "awg_{:.0f}G_{:.1f}".format(channel_spacing, fpr_alpha_factor))
        if not os.path.exists(save_dir):
            os.mkdir(save_dir)

        # Simulation specs
        wavelengths = np.linspace(1.535, 1.565, 1000)

        # Bare AWG
        if generate:
            awg = generate_awg(fsr=fsr, wg_width=wg_width, plot=plot, save_dir=save_dir, channel_spacing=channel_spacing, fpr_alpha_factor=fpr_alpha_factor, tag="bare")
        # awg.Layout().visualized()
        awgmrrset=threeringawgmrrset(awg=awg, num_rings=1)
        awgmrrsetlayout=awgmrrset.Layout()
        awgmrrsetlayout.visualize(annotate=True)

        if simulate:
            smat = simulate_awg(awg=awgmrrset, wavelengths=wavelengths, save_dir=save_dir, tag="bare")
        else:
            path = os.path.join(save_dir, "smatrix_bare.s16p")
            smat_finalized = i3.device_sim.SMatrix1DSweep.from_touchstone(path) if os.path.exists(path) else None

        if analyze:
            analyze_awg(smat, plot=plot, save_dir=save_dir, tag="bare")

        # Finished AWG
        if finalize:
            if generate:
                finalized_awg = finalize_awg(awg=awgmrrset, plot=plot, channel_spacing=channel_spacing, fpr_alpha_factor=fpr_alpha_factor, save_dir=save_dir, tag="finalized")

            if simulate:
                smat_finalized = simulate_awg(
                    awg=finalized_awg.blocks[3],
                    wavelengths=wavelengths,
                    save_dir=save_dir,
                    tag="finalized",
                )
            else:
                path = os.path.join(save_dir, "smatrix_finalized.s10p")
                smat_finalized = i3.device_sim.SMatrix1DSweep.from_touchstone(path) if os.path.exists(path) else None

            if analyze:
                analyze_final(smat_finalized, peak_threshold=-25, plot=plot, save_dir=save_dir, tag="finalized")

        print("Done")
