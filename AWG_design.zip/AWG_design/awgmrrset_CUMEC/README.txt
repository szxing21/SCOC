This project provides code for the design and optional simulation of an AWG-based photonic device using the Luceda IPKISS platform and the CSiP180Al PDK. The design integrates an arrayed waveguide grating (AWG) with a three-ring microring resonator filter structure.

The workflow includes four configurable stages: generation, simulation, analysis, and finalization. Users can adjust design parameters such as channel spacing, waveguide width, and the free spectral range (FSR). Layouts are automatically visualized during the design process, and simulation results (if enabled) are saved for further analysis.

Environment Requirements:

Python 3.6+

Luceda IPKISS (with valid license)

NumPy

Custom modules: CSiP180Al, ipkiss3, rect_awg/, and importawg/

Simulation and analysis can be enabled via flags in the script. Output files are saved under a structured designs/ directory named according to the design parameters.

This code is intended for researchers and engineers working in silicon photonics design and AWG filter prototyping.