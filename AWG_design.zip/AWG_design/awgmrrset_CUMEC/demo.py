import CSiP180Al.all as pdk
from opa.cell import OPA, RoutedOPA
from opa.simulate import simulate_opa
import pylab as plt
import numpy as np
import os

tag = "routed_opa"

# Heater
heater = pdk.HeatedWaveguide(name="heated_wav")
heater.Layout(shape=[(0, 0), (1000.0, 0.0)])

# Unrouted OPA
opa = OPA(name="opa_array", heater=heater, levels=3)

# Routed OPA
opa_routed = RoutedOPA(dut=opa)
opa_routed_lv = opa_routed.Layout()
opa_routed_lv.write_gdsii("{}.gds".format(tag))

# Simulation
res = simulate_opa(cell=opa_routed)

fig = plt.figure()
for cnt in range(opa._get_n_outputs()):
    plt.plot(res.timesteps[1:], np.unwrap(np.angle(res["out{}".format(cnt)]))[1:], label="out{}".format(cnt))

plt.title("Routed OPA - Phase")
plt.xlabel("Time step")
plt.ylabel("Phase")
plt.legend()
plt.show()
plt.tight_layout()
fig.savefig(os.path.join("{}_phase.png".format(tag)), bbox_inches="tight")
print("Done")