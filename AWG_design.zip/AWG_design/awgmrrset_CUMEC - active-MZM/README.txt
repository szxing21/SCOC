This project contains the code for designing and simulating an AWG-based photonic device using the Luceda IPKISS platform. It includes the generation of an arrayed waveguide grating (AWG), integration with microring resonators (MRRs), photodetectors (PDs), and Mach-Zehnder modulators (MZMs). The code supports design, optional simulation, result analysis, and finalization.

The script allows users to configure key parameters such as the number of channels, channel spacing, and waveguide width. Results including layout files and optional simulation outputs are saved under a structured folder based on the design parameters.

Environment Requirements:

Python 3.6 or higher

Luceda IPKISS (with valid license)

NumPy

Custom modules provided in the project (e.g., rect_awg, awg_generate, importawg)

Please note that a valid Luceda IPKISS license is required to run layout and simulation functionalities, as they rely on proprietary libraries. A README has been included to guide users through the device design flow.

This setup is intended for researchers and engineers working on silicon photonics and photonic computing system design.