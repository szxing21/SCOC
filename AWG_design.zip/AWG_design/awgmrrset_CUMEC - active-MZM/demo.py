from awg_generate import awg_generate
# from rect_awg import (
#     generate_rect_awg_with_strip_wg_apertures,
#     generate_rect_awg_with_rib_wg_apertures,
#     generate_rect_awg_with_rib_mmi_apertures,
# )

awg_generate(
    center_wavelength=1.55,
    channel_spacing_ghz=100.0,
    n_channels=8,
    ap_io_ap_width=2.0,
    ap_io_taper_length=50.0,
    ap_array_ap_width=2.0,
    ap_array_taper_length=50.0,
    wg_io_width=0.45,
    wg_array_width=0.45,
    wg_array_width_wide=1.0,
    n_arms_dummy=2,
    simulate=True,
    visualize=False,
)