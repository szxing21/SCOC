from csip130c import all as pdk  # noqa
from ipkiss3 import all as i3
from ipkiss3.all import START, END
from csip130c.all import BP_60_80, ABSORBER
from picazzo3.wg.spirals import FixedLengthSpiralRounded
import csip130c_awg.all as awg_pdk
import numpy as np
import pylab as plt
class awgmrrset(i3.Circuit):
    awg = i3.ChildCellProperty()
    splitter = i3.ChildCellProperty()
    BP = i3.ChildCellProperty()
    spacing_x = i3.PositiveNumberProperty(default=300.0)
    spacing_y = i3.PositiveNumberProperty(default=127.0)
    spacing_l = i3.PositiveNumberProperty(default=4)
    spacing_m = i3.PositiveNumberProperty(default=10)
    wm = i3.PositiveNumberProperty(default=5)
    reference_y = i3.PositiveNumberProperty(default=100)
    num_ports = i3.IntProperty(default=8, doc="number of the rings")

    def _default_splitter(self):
        return pdk.RingFilterWithTerminator(ring_num=1)
    def _default_BP(self):
        return pdk.BP_60_80()
    def _default_insts(self):
        insts = {
            "awg": self.awg,
            'PadG': BP_60_80(),
        }

        for i in range(1, num_ports+1):
            mrr_key = f"mrr{i}"
            pad_key = f"Pad{i}"
            insts[mrr_key] = self.splitter
            insts[pad_key] = BP()

        return insts
    def _default_specs(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y*2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        sp_m = self.spacing_m
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        tt = i3.ElectricalWireTemplate()
        tt.Layout(width=5, layer=i3.TECH.PPLAYER.M1.DRW)
        num_ports = self.num_ports
        ports = []
        # for i in range(num_ports):
        #     port = i3.OpticalPort(name="out"+str(i+1), position=(600, -30-sp_y / 4-ref_y + sp_y / 2 * (15 - i)),
        #                           angle=180,
        #                           trace_template=tt1)
        #     ports.append(port)
        # 现在，ports列表包含了port1, port2, port3...
        # port1, port2, port3, port4, port5, port6, port7, port8, port9, port10, port11, port12, port13, port14, port15
        # , port16 = ports

        specs = [
            i3.FlipH("awg"),
            i3.Place("awg", (0, 0), angle=270),
        ]

        for i in range(1, num_ports+1):
            mrr_key = f"mrr{i}:in_1"
            offset_y = -ref_y + sp_y * (8 - i)
            specs += i3.PlaceRelative(mrr_key, "awg:out1", (sp_x, offset_y)),

            connect_points = [("mrr{i}:in_1", f"awg:out{i}")]
            control_points = [i3.V(START - sp_x / 2 - sp_l * (8 - i)), i3.H(START - sp_y * (8 - i) + sp_l * (8 - i))]

            specs += i3.ConnectManhattan(
                    connect_points,
                    control_points=control_points,
                    bend_radius=10,
                    trace_template=tt1
                ),

        mrr_names = [f"mrr{i}" for i in range(1, 9)]
        specs += i3.FlipV(mrr_names),
        specs += i3.Place("PadG:pad_M1", (650, 1800)),
        for i in range(num_ports):
            specs += i3.Place("Pad"+str(i+1)+":pad_M1", (-150+i*100, 1800)),
            specs += i3.ConnectManhattan(
                [
                    ("mrr"+str(8-i)+":elec2", "Pad"+str(i+1)+":pad_M1")],
                control_points=[i3.V(START - 50 - sp_m * (8-i)), i3.H(END - 50 - sp_m * (8-i))],
                bend_radius=10,
                trace_template=tt,
            ),
            specs += i3.ConnectManhattan(
                [
                    ("mrr" + str(8 - i) + ":elec1", "PadG:pad_M1")],
                # control_points=[i3.V(START - sp_x / 2 - sp_l * 1), i3.H(START - sp_y * 1 + sp_l * 1)],
                bend_radius=10,
                trace_template=tt,
            ),
        return specs

    def _default_exposed_ports(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y * 2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        num_ports = self.num_ports
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5)
        num_ports = 16
        ports = []
        for i in range(num_ports):
            port = i3.OpticalPort(name="out_" + str(i + 1),
                                  position=(600, -30 - sp_y / 4 - ref_y + sp_y / 2 * (num_ports -1 - i)),
                                  angle=180,
                                  trace_template=tt1)
            ports.append(port)

        # 现在，ports列表包含了port1, port2, port3...
        port1, port2, port3, port4, port5, port6, port7, port8, port9, port10, port11, port12, port13, port14, port15, port16 = ports
        exposed_ports = {}

        for i in range(1, 9):
            exposed_ports[f"awg:in{i}"] = f"in{i}"

        for j in range(1, 9):
            for k in range(1, 3):
                port_name = f"mrr{j}:out_{k}"
                exposed_ports[port_name] = f"out{j * 2 - (2 - k)}"

        return exposed_ports
class threeringawgmrrset(i3.Circuit):
    awg = i3.ChildCellProperty()
    splitter = i3.ChildCellProperty()
    BP = i3.ChildCellProperty()
    spacing_x = i3.PositiveNumberProperty(default=300.0)
    spacing_y = i3.PositiveNumberProperty(default=127.0)
    spacing_l = i3.PositiveNumberProperty(default=4)
    spacing_m = i3.PositiveNumberProperty(default=10)
    spacing_r = i3.PositiveNumberProperty(default=150)
    spacing_p = i3.PositiveNumberProperty(default=80)
    wm = i3.PositiveNumberProperty(default=5)
    reference_y = i3.PositiveNumberProperty(default=100)
    num_ports = i3.IntProperty(default=8, doc="number of the ports")
    num_rings = i3.IntProperty(default=3, doc="number of the filters")
    def _default_splitter(self):
        return pdk.RingFilterall(ring_num=2)
    def _default_BP(self):
        return BP_60_80()
    def _default_terminator(self):
        return ABSORBER()
    def _default_insts(self):
        num_ports = self.num_ports
        num_rings = self.num_rings
        insts = {
            "awg": self.awg,
        }
        for j in range(num_rings):
            insts["PadG_" + str(j + 1)] = BP_60_80()
        for i in range(num_ports):
            for j in range(num_rings):
                insts["mrr_" + str(i + 1) + "_" + str(j+1)] = self.splitter
                insts["Pad_" + str(i + 1) + "_" + str(j+1)] = BP_60_80()
                if j == num_rings-1:
                    insts["ab_" + str(i + 1) + "_" + str(j + 1)] = ABSORBER()
        return insts

    def _default_specs(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y*2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        sp_m = self.spacing_m
        sp_r = self.spacing_r
        sp_p = self.spacing_p
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        ttm1 = i3.ElectricalWireTemplate()
        ttm1.Layout(width=5, layer=i3.TECH.PPLAYER.M1.DRW)
        ttm2 = i3.ElectricalWireTemplate()
        ttm2.Layout(width=20, layer=i3.TECH.PPLAYER.M1.DRW)
        num_ports = self.num_ports
        num_rings = self.num_rings
        specs = [i3.FlipH("awg"),
                 i3.Place("awg", (0, 0), angle=270)]
        # flipvstr = []
        for i in range(num_ports):
            for j in range(num_rings):
                if j == 0:
                    specs += i3.PlaceRelative("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1", "awg:out1",
                                              (sp_x, -ref_y + sp_y * (num_ports-1-i))),
                    specs += i3.ConnectManhattan(
                        [
                            ("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1", "awg:out" + str(i + 1))],
                        control_points=[i3.V(START - sp_x / 2 - sp_l * (num_ports-1 - i)),
                                        i3.H(START - sp_y * (num_ports-1 - i) + sp_l * (num_ports-1 - i))],
                        bend_radius=10,
                        trace_template=tt1
                    ),
                else:
                    specs += i3.PlaceRelative("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1",
                                              "mrr_" + str(i + 1) + "_" + str(j) + ":out_2",
                                              (sp_r, 0)),
                    specs += i3.ConnectManhattan(
                        [
                            ("mrr_" + str(i + 1) + "_" + str(j + 1) + ":out_1",
                             "mrr_" + str(i + 1) + "_" + str(j) + ":in_2")],
                        bend_radius=10,
                        trace_template=tt1
                    ),
                    specs += i3.ConnectManhattan(
                        [
                            ("mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_1",
                             "mrr_" + str(i + 1) + "_" + str(j) + ":out_2")],
                        bend_radius=10,
                        trace_template=tt1
                    ),
                if j == num_rings - 1:
                    specs += i3.PlaceRelative("ab_" + str(i + 1) + "_" + str(j + 1) + ":in",
                                              "mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_2",
                                              (1, 0), angle=180),
                    specs += i3.ConnectManhattan(
                        [("ab_" + str(i + 1) + "_" + str(j + 1) + ":in",
                          "mrr_" + str(i + 1) + "_" + str(j + 1) + ":in_2")],
                        bend_radius=10,
                        trace_template=tt1
                    ),
        for j in range(num_rings):
            i = num_ports
            specs += i3.PlaceRelative("PadG_" + str(j + 1) + ":elec_port",
                                      "mrr_" + str(1) + "_" + str(num_rings) + ":in_2",
                                      (i * sp_p + (j - num_rings) * (num_ports + 1) * sp_p,
                                       100 + sp_m * ((num_ports + 4) * num_rings)),
                                      angle=0),

        for i in range(num_ports):
            for j in range(num_rings):
                specs += i3.PlaceRelative("Pad_" + str(i + 1) + "_" + str(j + 1) + ":elec_port",
                                          "mrr_" + str(1) + "_" + str(num_rings) + ":in_2",
                                          (i * sp_p + (j - num_rings) * (num_ports + 1) * sp_p,
                                           100 + sp_m * ((num_ports + 4) * num_rings)),
                                          angle=0),
                specs += i3.ConnectManhattan(
                    [
                        ("mrr_" + str(num_ports - i) + "_" + str(j + 1) + ":elec2",
                         "Pad_" + str(i + 1) + "_" + str(j + 1) + ":elec_port")],
                    control_points=[i3.V(START - 20 - sp_m * (num_ports - i)),
                                    i3.H(END - 50 - sp_m * ((num_ports+4) * (num_rings - j) - i))],
                    bend_radius=10,
                    trace_template=ttm1,
                ),
                specs += i3.ConnectManhattan(
                    [
                        ("mrr_" + str(num_ports - i) + "_" + str(j + 1) +":elec1", "PadG_" + str(j + 1) + ":elec_port")],
                    control_points=[i3.V(START), i3.H(END - 50 - sp_m * ((num_ports+4) * (num_rings - 1 - j) + 2.5))],
                    bend_radius=10,
                    trace_template=ttm2,
                ),
        return specs

    def _default_exposed_ports(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y * 2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        num_ports = self.num_ports
        num_rings = self.num_rings
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5)
        exposed_ports = {}
        for i in range(num_ports):
            j = num_rings-1
            exposed_ports["mrr_" + str(i + 1) + "_" + str(j + 1) + ":out_2"] = "out" + str(2 * i + 2)
            exposed_ports["awg:in"+str(i+1)] = "in" + str(i + 1)
            j = 0
            exposed_ports["mrr_" + str(i + 1) + "_" + str(j + 1) + ":out_1"] = "out" + str(2 * i + 1)
        return exposed_ports


class addpd(i3.Circuit):
    awg = i3.ChildCellProperty()
    PD = i3.ChildCellProperty()
    BP = i3.ChildCellProperty()
    spacing_x = i3.PositiveNumberProperty(default=300.0)
    spacing_y = i3.PositiveNumberProperty(default=127.0)
    spacing_l = i3.PositiveNumberProperty(default=4)
    spacing_m = i3.PositiveNumberProperty(default=10)
    wm = i3.PositiveNumberProperty(default=5)
    reference_y = i3.PositiveNumberProperty(default=100)
    num_ports = i3.IntProperty(default=8, doc="number of the rings")

    def _default_PD(self):
        return pdk.GPD_1550_unit()

    def _default_BP(self):
        return pdk.BP_60_80()
    def _default_insts(self):
        num_ports = self.num_ports
        insts = {
            "awg": self.awg,
        }
        for i in range(num_ports*2):
            insts["PD_" + str(i + 1)] = pdk.GPD_1550_unit()
        return insts

    def _default_specs(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y*2
        ref_y = self.reference_y
        # sp_l = self.spacing_l
        # sp_m = self.spacing_m
        # sp_p = self.spacing_p
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        ttm1 = i3.ElectricalWireTemplate()
        ttm1.Layout(width=5, layer=i3.TECH.PPLAYER.M1.DRW)
        ttm2 = i3.ElectricalWireTemplate()
        ttm2.Layout(width=20, layer=i3.TECH.PPLAYER.M1.DRW)
        num_ports = self.num_ports
        specs = [i3.Place("awg", (0, 0))]
        # flipvstr = []
        for i in range(num_ports):
            specs += i3.PlaceRelative("PD_" + str(2 * i + 1) + ":in_1", "awg:out" + str(2 * i+1), (sp_x, sp_y/4)),
            specs += i3.PlaceRelative("PD_" + str(2 * i + 2) + ":in_1", "awg:out" + str(2 * i+1), (sp_x, -sp_y/4)),
            specs += i3.ConnectManhattan(
                [
                    ("PD_" + str(2 * i + 1) + ":in_1", "awg:out" + str(2 * i + 1))],
                control_points=[i3.H(START), i3.V(END - ref_y)],
                bend_radius=10,
                trace_template=tt1
            ),
            specs += i3.ConnectManhattan(
                [
                    ("PD_" + str(2 * i + 2) + ":in_1", "awg:out" + str(2 * i + 2))],
                control_points=[i3.H(START), i3.V(END + ref_y)],
                bend_radius=10,
                trace_template=tt1
            ),
        return specs

    def _default_exposed_ports(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y * 2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        num_ports = self.num_ports
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5)
        exposed_ports = {}
        for i in range(num_ports):
            exposed_ports["awg:in"+str(i+1)] = "in" + str(i + 1)
        return exposed_ports


class addmzm(i3.Circuit):
    awg = i3.ChildCellProperty()
    BP = i3.ChildCellProperty()
    spacing_x = i3.PositiveNumberProperty(default=300.0)
    spacing_y = i3.PositiveNumberProperty(default=127.0)
    spacing_l = i3.PositiveNumberProperty(default=4)
    spacing_m = i3.PositiveNumberProperty(default=10)
    spacing_mzm = i3.PositiveNumberProperty(default=800)
    spacing_mzmy = i3.PositiveNumberProperty(default=300)
    wm = i3.PositiveNumberProperty(default=5)
    reference_y = i3.PositiveNumberProperty(default=100)
    num_ports = i3.IntProperty(default=8, doc="number of the rings")

    def _default_MZM(self):
        return pdk.MZM_TE_1550()

    def _default_BP(self):
        return pdk.BP_60_80()

    def _default_insts(self):
        num_ports = self.num_ports
        sp_mzm = self.spacing_mzm
        sp_y = self.spacing_y
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        insts = {
            "awg": self.awg,
        }
        for i in range(num_ports):
            insts["mzm_" + str(i + 1)] = pdk.MZM_TE_1550()
            if i < num_ports-1:
                cell = FixedLengthSpiralRounded(total_length=sp_mzm * (num_ports-i-1), n_o_loops=num_ports-i-1,
                                         trace_template=tt1)
                layout = cell.Layout(
                    bend_radius=10.0,
                    incoupling_length=10.0,
                    spacing=4,
                    stub_direction="V",  # either H or V
                    growth_direction="H",  # either H or V
                )
                # layout.visualize(annotate=True)
                insts["spiral_" + str(i + 1)] = cell

            cell = FixedLengthSpiralRounded(total_length=(sp_mzm - sp_y) * (num_ports - i),
                                            n_o_loops=num_ports - i,
                                            trace_template=tt1)
            layout = cell.Layout(
                bend_radius=10.0,
                incoupling_length=10.0,
                spacing=4,
                stub_direction="V",  # either H or V
                growth_direction="H",  # either H or V
            )
            # layout.visualize(annotate=True)
            insts["spiral2_" + str(num_ports - i)] = cell
        return insts

    def _default_specs(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y
        sp_mzm = self.spacing_mzm
        sp_mzm1 = self.spacing_mzmy
        ref_y = self.reference_y
        sp_l = self.spacing_l
        # sp_m = self.spacing_m
        # sp_p = self.spacing_p
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5, cladding_width=6)
        ttm1 = i3.ElectricalWireTemplate()
        ttm1.Layout(width=5, layer=i3.TECH.PPLAYER.M1.DRW)
        ttm2 = i3.ElectricalWireTemplate()
        ttm2.Layout(width=20, layer=i3.TECH.PPLAYER.M1.DRW)
        num_ports = self.num_ports
        specs = [i3.Place("awg", (0, 0))]
        for i in range(num_ports):
            specs += i3.PlaceRelative("mzm_" + str(i + 1) + ":opt_out", "awg:in1",
                                      (-sp_mzm * (i+1), sp_mzm1), angle=270),
            specs += i3.PlaceRelative("spiral2_" + str(i+1) + ":in", "mzm_" + str(i + 1) + ":opt_in",
                                      (0, sp_mzm1), angle=90),
            specs += i3.ConnectManhattan(
                [
                    ("spiral2_" + str(i + 1) + ":out", "mzm_" + str(i + 1) + ":opt_in")],
                bend_radius=10,
                trace_template=tt1
            ),
            if i < num_ports - 1:
                specs += i3.PlaceRelative("spiral_" + str(i + 1) + ":out", "mzm_" + str(i + 1) + ":opt_out",
                                          (0, -sp_mzm1), angle=270),
                specs += i3.ConnectManhattan(
                    [
                        ("spiral_" + str(i + 1) + ":out", "awg:in" + str(i + 1))],
                    control_points=[i3.H(START - ref_y + sp_l * (num_ports - 1 - i))],
                    bend_radius=10,
                    trace_template=tt1
                ),
                specs += i3.ConnectManhattan(
                    [
                        ("spiral_" + str(i + 1) + ":in", "mzm_" + str(i + 1) + ":opt_out")],
                    bend_radius=10,
                    trace_template=tt1
                ),

            else:
                specs += i3.ConnectManhattan(
                    [
                        ("mzm_" + str(i + 1) + ":opt_out", "awg:in" + str(i + 1))],
                    control_points=[i3.H(START - sp_mzm1 - ref_y + sp_l * (num_ports - 1 - i))],
                    bend_radius=10,
                    trace_template=tt1
                ),
        return specs
    def _default_exposed_ports(self):
        sp_x = self.spacing_x
        sp_y = self.spacing_y * 2
        ref_y = self.reference_y
        sp_l = self.spacing_l
        num_ports = self.num_ports
        tt1 = pdk.StripWaveguideTemplate()
        tt1.Layout(core_width=0.5)
        exposed_ports = {}
        for i in range(num_ports):
            exposed_ports["spiral2_" + str(i + 1) + ":in"] = "in" + str(i + 1)
        return exposed_ports
