# Copyright (C) 2020 Luceda Photonics
import os
import json
from cumec_awg.all import SiSlabTemplate, SiRibAperture, SiRibMMIAperture
from CSiP180Al import all as pdk
import ipkiss3.all as i3

import awg_designer.all as awg
import numpy as np

from csip130c import all as pdk
# from csip130c_awg import materials_plugin
import ipkiss3.all as i3
from csip130c_awg.all import SiSlabTemplate, SiRibAperture,SiAperture, SiStarCoupler, SiRibMMIAperture, SiMMIAperture
import awg_designer.all as awg
import awg_designer.all as awg_des
import csip130c_awg.all as awg_pdk
import numpy as np
import matplotlib.pyplot as plt


def generate_awg(fsr, wg_width=0.5, plot=True, output_aperture_spacing=2.5, fpr_alpha_factor=1.6, channel_spacing=100, save_dir=None, n_channels=8, tag=""):
    """Custom AWG generating function. If you make an AWG, you should write one of your own.
    Parameters are the things you want to vary as well as options to control if you
    plot and where you save your data.

    Parameters
    ----------
    fsr : float
          FSR of the AWG in Hz
    wg_width : float, default: 0.4, optional
               Width of the waveguides in the array
    plot : bool, default: True, optional
           If true the AWG is plotted
    save_dir: str, default: None, optional
              If specified, a GDSII file is saved in this directory
    tag: str, optional
         String used to give a name to saved files
    output_aperture_spacing:
    fpr_alpha_factor:
    channel_spacing:
    Returns
    -------
    cwdm_awg : i3.PCell
               AWG PCell
    """

    center_frequency = awg.wavelength_to_frequency(1.550)  # GHz
    # channel_spacing = 100.0  # GHz
    # Physical specifications
    # output_aperture_spacing = 2.8
    # fpr_alpha_factor = 1.2

    # Subcomponents
    print("Instantiating subcomponents...\n")
    slab = SiSlabTemplate()
    # slab.Layout().cross_section().visualize()

    wgt = pdk.SWG1000()
    wgt.CircuitModel()

    wgt1 = pdk.SWG450_CTE()
    wgt1.CircuitModel()

    # you can also use the SiRibMMIAperture, but pay attention to adjust "layers_in" in the contour of the sc_in
    ap = SiAperture(slab_template=slab,
                    transition_length=30.,
                    wire_width=0.5,
                    aperture_core_width=1.3
                    )

    # ap = SiMMIAperture(slab_template=slab,
    #                    wire_width=0.45,
    #                    taper_length=30.,
    #                    mmi_length=8.9,
    #                    mmi_core_width = 2.9,
    #                    )

    ap_lay = ap.Layout()
    # ap_lay.write_gdsii("ap_lay.gds")
    # ap_lay.visualize(annotate=True)
    # ap_lay.visualize_2d(process_flow=i3.TECH.VFABRICATION.PROCESS_FLOW_NEW)

    simulation_width = 6
    size_info = ap_lay.size_info()
    window = i3.SizeInfo(
        west=size_info.west,
        east=size_info.east,
        north=size_info.center[1] + 0.5 * simulation_width,
        south=size_info.center[1] - 0.5 * simulation_width
    )
    ap.CircuitModel(simulation_wavelengths=[1.55])
    # env = i3.Environment(wavelength=1.55)
    # ap_field = ap.FieldModelFromCamfr(simulation_window=window)
    # ap_field.get_fields(environment=env).visualize()
    # ap_field.get_aperture_fields2d(mode=0, environment=env).visualize()

    ap1 = SiAperture(slab_template=slab,
                     transition_length=30.,
                     wire_width=0.5,
                     aperture_core_width=1.5
                     )
    # ap1_lay = ap1.Layout()
    # ap1_lay.visualize(annotate=True)
    # ap1_lay.visualize_2d(process_flow=i3.TECH.VFABRICATION.PROCESS_FLOW_NEW)

    ap1.CircuitModel(simulation_wavelengths=[1.55])
    # env = i3.Environment(wavelength=1.55)
    # ap1_field = ap1.FieldModelFromCamfr()
    # ap1_field.get_fields(environment=env).visualize()
    # ap1_field.get_aperture_fields2d(mode=0, environment=env).visualize()

    # key parameters definition
    center_frequency = awg.wavelength_to_frequency(1.55)
    # n_channels = 8
    # channel_spacing = 100

    # output_aperture_spacing = 2.8
    # fpr_alpha_factor = 1.2

    design_params = awg.get_layout_params_1xM_demux_ghz(aperture_in=ap,
                                                        aperture_arms=ap1,
                                                        aperture_out=ap,
                                                        waveguide_template=wgt,
                                                        output_spacing=output_aperture_spacing,
                                                        alpha_factor=fpr_alpha_factor,
                                                        M=n_channels,
                                                        grating_period=2,
                                                        center_frequency=center_frequency,
                                                        channel_spacing=channel_spacing,
                                                        FSR=fsr,
                                                        verbose=True
                                                        )

    print(design_params)

    angles_arms_out = design_params['angles_arms_out']
    angles_arms_in = design_params['angles_arms_in']
    angles_out = design_params['angles_out']
    angles_in = np.array([0.0])
    grating_radius_output = design_params["R_grating"]
    grating_radius_input = design_params['R_input']
    n_arms = design_params['N_arms']
    delay_length = design_params['delay_length']

    n_dummies = 2

    # generate the apertures
    out_array, out_array_angles = awg.get_apertures_angles_with_dummies(
        apertures=[ap1] * n_arms,
        angles=angles_arms_out,
        n_dummies=n_dummies
    )
    out_ports, out_ports_angles = awg.get_apertures_angles_with_dummies(
        apertures=[ap] * len(angles_out),
        angles=angles_out,
        n_dummies=n_dummies
    )

    out_array_aperture, out_ports_aperture, out_array_xforms, out_ports_xforms = awg.get_star_coupler_apertures(
        apertures_arms=out_array,
        apertures_ports=out_ports,
        angles_arms=out_array_angles,
        angles_ports=out_ports_angles,
        radius=grating_radius_output,
        mounting='rowland',
        input=False
    )

    # out_ports_aperture.Layout(aperture_transformations=out_ports_xforms).visualize()
    # out_array_aperture.Layout(aperture_transformations=out_array_xforms).visualize()

    factor = 0.5
    # 0.5 - Rowland, 1.0 - Confocal

    contour = awg.get_star_coupler_extended_contour(
        apertures_in=out_array,
        apertures_out=out_ports,
        trans_in=out_array_xforms,
        trans_out=out_ports_xforms,
        radius_in=grating_radius_output,
        radius_out=grating_radius_output * factor,
        extension_angles=(10, 10),
        # extension_angles can control the contour for star coupler
        aperture_extension=(0.1, 0.01),
        # aperture_extension can remove the acute angles between wgs and slab
        layers_in=[i3.TECH.PPLAYER.FETCH.COR],
        layers_out=[i3.TECH.PPLAYER.FETCH.COR]
        # layers_out=[i3.TECH.PPLAYER.SETCH.COR, i3.TECH.PPLAYER.SETCH.CLD]
        # layers for operation
    )

    # visualize the star coupler
    i3.LayoutCell(name="contour of the fpr").Layout(
        elements=[i3.Boundary(i3.TECH.PPLAYER.FETCH.COR, shape=contour)])

    # define the input and output star coupler
    sc_out = SiStarCoupler(aperture_out=out_ports_aperture,
                           aperture_in=out_array_aperture
                           )
    sc_out_layout = sc_out.Layout(contour=contour)
    # sc_out_layout.visualize(annotate=True)
    sc_out.CircuitModel(simulation_wavelengths=[1.55])

    sc_in_array, sc_in_array_angles = awg.get_apertures_angles_with_dummies(
        apertures=[ap1] * n_arms,
        angles=angles_arms_in,
        n_dummies=n_dummies
    )

    sc_in_ports, sc_in_ports_angles = awg.get_apertures_angles_with_dummies(
        apertures=[ap] * len(angles_out),
        angles=angles_out,
        n_dummies=n_dummies,
        # angle_step=5.0
    )

    sc_in_array_aperture, sc_in_ports_aperture, sc_in_array_xforms, sc_in_ports_xforms = awg.get_star_coupler_apertures(
        apertures_arms=sc_in_array,
        apertures_ports=sc_in_ports,
        angles_arms=sc_in_array_angles,
        angles_ports=sc_in_ports_angles,
        radius=grating_radius_input,
        mounting='rowland',
        input=True
    )
    contour = awg.get_star_coupler_extended_contour(
        apertures_in=sc_in_ports,
        apertures_out=sc_in_array,
        trans_in=sc_in_ports_xforms,
        trans_out=sc_in_array_xforms,
        radius_in=grating_radius_input * 0.5,
        radius_out=grating_radius_input,
        extension_angles=(10, 10),
        aperture_extension=(0.01, 0.1),
        # layers_in=[i3.TECH.PPLAYER.FETCH.COR],
        # layers_in=[i3.TECH.PPLAYER.SETCH.COR, i3.TECH.PPLAYER.SETCH.CLD],
        # layers_out=[i3.TECH.PPLAYER.FETCH.COR]
        # layers_out=[i3.TECH.PPLAYER.SETCH.COR, i3.TECH.PPLAYER.SETCH.CLD]
    )

    # visualize the star coupler
    i3.LayoutCell(name="contour of the fpr").Layout(
        elements=[i3.Boundary(i3.TECH.PPLAYER.FETCH.COR, shape=contour)])

    sc_in = SiStarCoupler(
        aperture_in=sc_in_ports_aperture,
        aperture_out=sc_in_array_aperture
    )
    sc_in_layout = sc_in.Layout(contour=contour)
    # sc_in_layout.visualize(annotate=True)
    sc_in.CircuitModel(simulation_wavelengths=[1.55])

    # Create waveguide arrays
    delays = [delay_length * i for i in range(n_arms)]
    print((len(delays)))
    out_ports = []
    out_ports.extend(sc_in_layout.east_ports)
    out_ports.extend(sc_in_layout.north_ports)
    out_ports.extend(sc_in_layout.south_ports)
    wg_array = awg.RectangularTaperedWaveguideArray(start_ports=out_ports,
                                                    delay_lengths=delays,
                                                    straight_trace_template=pdk.SWG1000()
                                                    )
    wg_array.Layout(bundle_spacing=200.0,
                    taper_length=10.,
                    # route_properties={"bend_radius":10.}
                    )

    # Create the awg
    cwdm_awg = awg.ArrayedWaveguideGrating(star_coupler_in=sc_in,
                                           star_coupler_out=sc_out,
                                           waveguide_array=wg_array
                                           )
    cwdm_awg_layout = cwdm_awg.Layout()
    if plot:
        cwdm_awg_layout.visualize(annotate=0)
    if save_dir:
        gds_path = os.path.abspath(os.path.join(save_dir, "awg_{}.gds".format(tag)))
        cwdm_awg_layout.write_gdsii(gds_path)
        print("{} written.".format(gds_path))
    # f_0 = center_frequency - 0.5 * (n_channels - 1) * channel_spacing
    # channel_freq = f_0 + channel_spacing * np.arange(n_channels)
    # channel_wav = awg.frequency_to_wavelength(channel_freq)[::-1]
    # wavelengths = np.linspace(1.52, 1.56, 1001)
    # awg_s = cwdm_awg.get_default_view(i3.CircuitModelView).get_smatrix(wavelengths=wavelengths)
    # plt.figure(figsize=(4, 3))
    # for i in range(n_channels):
    #     plt.plot(wavelengths, 10 * np.log10(np.abs(awg_s["out{}".format(i + 1), "in1"]) ** 2),
    #              label="out{}".format(i + 1))
    #     plt.axvline(channel_wav[i])
    #
    # plt.xlim(channel_wav[0] - 0.005, channel_wav[-1] + 0.005)
    # plt.ylim([-60.0, -0.0])
    # plt.xlabel("Wavelength [um]")
    # plt.ylabel("Transmission [dB]")
    # plt.show()
    return cwdm_awg
