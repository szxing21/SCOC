# Copyright (C) 2020 Luceda Photonics

import csip130c.all as pdk
import ipkiss3.all as i3
import numpy as np
import os
from awg_generate import awg_generate
# from rect_awg.generate_new import generate_awg
from rect_awg.simulate import simulate_awg
from rect_awg.finalize import finalize_awg
from rect_awg.analyze_final import analyze_final
from rect_awg.analyze import analyze_awg
from importawg import awgmrrset, threeringawgmrrset, addpd, addmzm
# Actions
generate = 1
simulate = 0
analyze = 0
finalize = 1
plot = 0

# Specifications
n_channels = 8
# channel_spacing = 200  # GHz
wg_width = 0.5


cslist=[100]
faflist=[1]


for cs in cslist:
    for faf in faflist:

        # twl = 2
        # oas = 4
        # faf = 1.6
        channel_spacing = cs
        fpr_alpha_factor = faf
        fsr = n_channels * channel_spacing
        # Creating a folder for results
        this_dir = os.path.abspath(os.path.dirname(__file__))
        designs_dir = os.path.join(this_dir, "designs")
        if not os.path.exists(designs_dir):
            os.mkdir(designs_dir)
        save_dir = os.path.join(designs_dir, "awg_{:.0f}G_{:.1f}".format(channel_spacing, fpr_alpha_factor))
        if not os.path.exists(save_dir):
            os.mkdir(save_dir)

        # Simulation specs
        wavelengths = np.linspace(1.535, 1.565, 1000)

        # Bare AWG
        if generate:
            awg = awg_generate(
                center_wavelength=1.55,
                channel_spacing_ghz=100.0,
                n_channels=8,
                ap_io_ap_width=2.0,
                ap_io_taper_length=50.0,
                ap_array_ap_width=2.0,
                ap_array_taper_length=50.0,
                wg_io_width=0.5,
                wg_array_width=0.5,
                wg_array_width_wide=1.0,
                n_arms_dummy=2,
                simulate=False,
                visualize=False,
            )
        # awglayout = awg.Layout().visualize(annotate=0)
        awgmrrset = threeringawgmrrset(awg=awg, num_ports=n_channels, num_rings=1, spacing_y=200)
        # awgmrrsetlayout=awgmrrset.Layout()
        # awgmrrsetlayout.visualize(annotate=True)
        awgaddpd = addpd(awg=awgmrrset, num_ports=n_channels, spacing_y=200)
        awgaddpdlayout = awgaddpd.Layout()
        awgaddpdlayout.visualize(annotate=True)
        awgaddmzm = addmzm(awg=awgaddpd, num_ports=n_channels)
        awgaddmzmlayout = awgaddmzm.Layout()
        awgaddmzmlayout.visualize(annotate=True)

        if simulate:
            smat = simulate_awg(awg=awgaddmzm, wavelengths=wavelengths, save_dir=save_dir, tag="bare")
        else:
            path = os.path.join(save_dir, "smatrix_bare.s16p")
            smat_finalized = i3.device_sim.SMatrix1DSweep.from_touchstone(path) if os.path.exists(path) else None

        if analyze:
            analyze_awg(smat, plot=plot, save_dir=save_dir, tag="bare")

        # Finished AWG
        if finalize:
            if generate:
                finalized_awg = finalize_awg(awg=awgaddmzm, plot=plot, channel_spacing=channel_spacing, fpr_alpha_factor=fpr_alpha_factor, save_dir=save_dir, n_channels=n_channels, tag="finalized")

            if simulate:
                smat_finalized = simulate_awg(
                    awg=finalized_awg.blocks[3],
                    wavelengths=wavelengths,
                    save_dir=save_dir,
                    tag="finalized",
                )
            else:
                path = os.path.join(save_dir, "smatrix_finalized.s10p")
                smat_finalized = i3.device_sim.SMatrix1DSweep.from_touchstone(path) if os.path.exists(path) else None

            if analyze:
                analyze_final(smat_finalized, peak_threshold=-25, plot=plot, save_dir=save_dir, tag="finalized")

        print("Done")
