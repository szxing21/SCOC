import csip130c.all as pdk  # noqa
import ipkiss3.all as i3
import numpy as np
import matplotlib.pyplot as plt
import awg_designer.all as awg_des
import csip130c_awg.all as awg_pdk
from pysics.basics.environment import Environment
from ipkiss3.pcell.routing.base import _RouteProperties

def awg_generate(
    center_wavelength=1.55,
    channel_spacing_ghz=100,
    n_channels=4,
    ap_io_ap_width=2.0,
    ap_io_taper_length=50.0,
    ap_io_spacing=0.5,
    ap_array_ap_width=2.0,
    ap_array_taper_length=50.0,
    ap_array_spacing=0.5,
    wg_io_width=0.45,
    wg_array_width=0.45,
    wg_array_width_wide=1.0,
    wg_array_bundle_spacing=None,
    wg_array_taper_length=10.0,
    mounting="rowland",
    n_arms=None,
    n_arms_dummy=2,
    min_bend_radius=10.0,
    dummy_angle_step_in=2.0,
    simulate=True,
    visualize=True,
    write_gds=True,
    tag="",
):

    ####################################################################################################################
    # Step 1. Some initializations.
    print(" ")
    print("Step 1. Some initializations.")

    fsr = (n_channels) * channel_spacing_ghz
    f_center = awg_des.frequency_to_wavelength(center_wavelength)
    f_0 = f_center - 0.5 * (n_channels - 1) * channel_spacing_ghz
    fs = f_0 + channel_spacing_ghz * np.arange(n_channels)
    wavelengths = awg_des.frequency_to_wavelength(fs)
    environment = Environment(wavelength=center_wavelength)

    ####################################################################################################################
    # Step 2. Define the waveguide and slab templates.
    print("Step 2. Define the waveguide and slab templates..")
    wg_array_tmpl = pdk.StripWaveguideTemplate()
    wg_array_tmpl.Layout(core_width=wg_array_width, cladding_width=wg_array_width + 10.0)
    wg_array_tmpl_wide = pdk.StripWaveguideTemplate()
    wg_array_tmpl_wide.Layout(core_width=wg_array_width_wide, cladding_width=wg_array_width_wide + 10.0)
    # ap_io_tmpl = pdk.StripWaveguideTemplate()
    # ap_io_tmpl.Layout(core_width=ap_io_ap_width, cladding_width=wg_array_width_wide + 10.0)
    # wg_array_tmpl = pdk.StripWaveguideTemplate()
    # wg_array_tmpl.Layout(core_width=wg_array_width_wide, cladding_width=wg_array_width_wide + 10.0)
    # wg_array_tmpl = (
    #     awg_pdk.StripWaveguideTemplate1Mode()
    #     .Layout(
    #         core_width=wg_array_width,
    #         cladding_width=wg_array_width + 10.0,
    #     )
    #     .cell
    # )
    # wg_array_tmpl_wide = (
    #     awg_pdk.StripWaveguideTemplate1Mode()
    #     .Layout(
    #         core_width=wg_array_width_wide,
    #         cladding_width=wg_array_width_wide + 10.0,
    #     )
    #     .cell
    # )
    slab_template = awg_pdk.SiFetchSlabTemplate()

    ####################################################################################################################
    # Step 3. Create the apertures at the star coupler
    print("Step 3. Create the apertures at the star coupler.")

    # Aperture for the input and output sides
    ap_io = awg_pdk.StripWgAperture(
        aperture_core_width=ap_io_ap_width,
        cladding_extension=4,
        wire_width=wg_io_width,
        taper_length=ap_io_taper_length,
        slab_template=slab_template,
    )
    # ap_io.Layout().visualize(annotate=True)
    # ap_io.Layout().visualize_2d(process_flow=awg_pdk.PROCESS_FLOW_FEOL_AWG)

    # Aperture for the waveguide array side
    ap_array = awg_pdk.StripWgAperture(
        aperture_core_width=ap_array_ap_width,
        wire_width=wg_array_width,
        taper_length=ap_array_taper_length,
        slab_template=slab_template,
    )
    # ap_array.Layout().visualize(annotate=True)
    # ap_array.Layout().visualize_2d(process_flow=awg_pdk.PROCESS_FLOW_FEOL_AWG)

    ####################################################################################################################
    # Step 4. Extract the simulation model for the aperture.
    print("Step 4. Extract the simulation model for the aperture.")

    ap_array.CircuitModel(simulation_wavelengths=[center_wavelength])
    ap_array_sm = ap_array.FieldModelFromCamfr()
    # ap_array_sm.get_fields(environment=environment).visualize()
    # ap_array_sm.get_aperture_fields2d(environment=environment).visualize()

    ap_io.CircuitModel(simulation_wavelengths=[center_wavelength])
    ap_io_sm = ap_io.FieldModelFromCamfr()
    # ap_io_sm.get_fields(environment=environment).visualize()
    # ap_io_sm.get_aperture_fields2d(environment=environment).visualize()

    ####################################################################################################################
    # Step 5. Use the design function to get the aperture locations and the delay lengths in the grating.
    print("Step 5. Use the design function to get the aperture locations and the delay lengths in the grating.")

    layout_params = awg_des.get_layout_params_1xM_demux_ghz(
        aperture_in=ap_io,
        aperture_arms=ap_array,
        aperture_out=ap_io,
        waveguide_template=wg_array_tmpl,
        grating_period=ap_array_ap_width + ap_array_spacing,
        output_spacing=ap_io_ap_width + ap_io_spacing,
        M=n_channels,
        center_frequency=f_center,
        channel_spacing=channel_spacing_ghz,
        FSR=fsr,
        N_arms=n_arms,
        verbose=True,
    )
    angles_ap_array_out = layout_params["angles_arms_out"]
    angles_ap_io_out = layout_params["angles_out"]
    angles_ap_array_in = layout_params["angles_arms_in"]
    delay_length = layout_params["delay_length"]

    ####################################################################################################################
    # Step 6.1. Generate the output star coupler.
    print("Step 6.1. Generate the output star coupler.")

    sc_out_array, sc_out_array_angles = awg_des.get_apertures_angles_with_dummies(
        apertures=[ap_array] * layout_params["N_arms"],
        angles=angles_ap_array_out,
        n_dummies=n_arms_dummy,
    )
    if angles_ap_io_out[0] > angles_ap_io_out[-1]:
        angles_ap_io_out = angles_ap_io_out[::-1]  # Reverse order, so the ports are named + ordered properly
    sc_out_ports, sc_out_ports_angles = awg_des.get_apertures_angles_with_dummies(
        apertures=[ap_io] * len(angles_ap_io_out),
        angles=angles_ap_io_out,
        n_dummies=n_arms_dummy,
    )

    (
        sc_out_array_aperture,
        sc_out_ports_aperture,
        sc_out_array_xforms,
        sc_out_ports_xforms,
    ) = awg_des.get_star_coupler_apertures(
        apertures_arms=sc_out_array,
        apertures_ports=sc_out_ports,
        angles_arms=sc_out_array_angles,
        angles_ports=sc_out_ports_angles,
        radius=layout_params["R_grating"],
        mounting="rowland",
        input=False,
    )

    contour = awg_des.get_star_coupler_extended_contour(
        apertures_in=sc_out_array,
        apertures_out=sc_out_ports,
        trans_in=sc_out_array_xforms,
        trans_out=sc_out_ports_xforms,
        radius_in=layout_params["R_grating"],
        radius_out=layout_params["R_grating"] if mounting == "confocal" else layout_params["R_grating"] * 0.5,
        extension_angles=(10, 10),
        aperture_extension=[0.1, 0.0],
        layers_in=[i3.TECH.PPLAYER.FETCH.COR],
        layers_out=[i3.TECH.PPLAYER.FETCH.COR],
    )

    sc_out = awg_des.StarCoupler(aperture_in=sc_out_array_aperture, aperture_out=sc_out_ports_aperture)
    sc_out_layout = sc_out.Layout(contour=contour)
    sc_out.CircuitModel(simulation_wavelengths=[center_wavelength])
    if visualize:
        sc_out_layout.visualize(annotate=True)

    ####################################################################################################################
    # Step 6.2. Generate the input star coupler.
    print("Step 6.2. Generate the input star coupler.")
    # sc_out_array, sc_out_array_angles = awg_des.get_apertures_angles_with_dummies(
    #     apertures=[ap_array] * layout_params["N_arms"],
    #     angles=angles_ap_array_out,
    #     n_dummies=n_arms_dummy,
    # )
    # if angles_ap_io_out[0] > angles_ap_io_out[-1]:
    #     angles_ap_io_out = angles_ap_io_out[::-1]  # Reverse order, so the ports are named + ordered properly
    # sc_out_ports, sc_out_ports_angles = awg_des.get_apertures_angles_with_dummies(
    #     apertures=[ap_io] * len(angles_ap_io_out),
    #     angles=angles_ap_io_out,
    #     n_dummies=n_arms_dummy,
    # )
    #

    sc_in_array, sc_in_array_angles = awg_des.get_apertures_angles_with_dummies(
        apertures=[ap_array] * layout_params["N_arms"],
        angles=angles_ap_array_in,
        n_dummies=n_arms_dummy,
    )
    sc_in_ports, sc_in_ports_angles = awg_des.get_apertures_angles_with_dummies(
        apertures=[ap_io] * len(angles_ap_io_out),
        angles=angles_ap_io_out,
        n_dummies=n_arms_dummy,
        # angle_step=dummy_angle_step_in,
    )

    R_input = layout_params["R_grating"]
    if R_input is None:
        R_input = layout_params["R_grating"]
    if mounting == "confocal":
        radius_in = R_input
    else:
        radius_in = R_input / 2.0

    (
        sc_in_array_aperture,
        sc_in_ports_aperture,
        sc_in_array_xforms,
        sc_in_ports_xforms,
    ) = awg_des.get_star_coupler_apertures(
        apertures_arms=sc_in_array,
        apertures_ports=sc_in_ports,
        angles_arms=sc_in_array_angles,
        angles_ports=sc_in_ports_angles,
        radius=R_input,
        mounting=mounting,
        input=True,
    )

    contour = awg_des.get_star_coupler_extended_contour(
        apertures_in=sc_in_ports,
        apertures_out=sc_in_array,
        trans_in=sc_in_ports_xforms,
        trans_out=sc_in_array_xforms,
        radius_in=radius_in,
        radius_out=R_input,
        extension_angles=(10, 10),
        aperture_extension=[0.1, 0.0],
        layers_in=[i3.TECH.PPLAYER.FETCH.COR],
        layers_out=[i3.TECH.PPLAYER.FETCH.COR],
    )

    sc_in = awg_des.StarCoupler(aperture_in=sc_in_ports_aperture, aperture_out=sc_in_array_aperture)
    sc_in_layout = sc_in.Layout(contour=contour)
    sc_in.CircuitModel(simulation_wavelengths=[center_wavelength])
    if visualize:
        sc_in_layout.visualize(annotate=True)

    ####################################################################################################################
    # Step 7. Create a rectangular AWG
    print("Step 7. Create a rectangular AWG")

    rprops = _RouteProperties(
        bend_radius=min_bend_radius,
        rounding_algorithm=i3.ShapeRound,
        min_straight=2.0,
        start_straight=1.0,
        end_straight=1.0,
        angle_step=1.0,
    )

    star_coupler_in_lv = sc_in.get_default_view(i3.LayoutView)
    star_coupler_out_lv = sc_out.get_default_view(i3.LayoutView)

    if wg_array_bundle_spacing is None:
        si1 = star_coupler_in_lv.size_info()
        si2 = star_coupler_out_lv.size_info()
        displacement = si1.south - si2.north
        bs1, bs2 = rprops.get_bend90_size()
        wg_array_bundle_spacing = (
            displacement - 4 * max((bs1, bs2)) - (rprops.start_straight + rprops.end_straight + wg_array_taper_length)
        )
        wg_array_bundle_spacing = i3.snap_value(abs(wg_array_bundle_spacing))

    # actual location of all the ports of the input and the output star coupler.
    sc_in_ports = star_coupler_in_lv.ports
    sc_out_ports = star_coupler_out_lv.ports.transform_copy(i3.Rotation(rotation=180.0))
    array_in_ports = [sc_in_ports["out{}".format(cnt + 1)] for cnt in range(star_coupler_in_lv.n_outputs)]
    array_out_ports = [sc_out_ports["in{}".format(cnt + 1)] for cnt in range(star_coupler_out_lv.n_inputs)]

    array = (
        awg_des.RectangularTaperedWaveguideArray(
            straight_trace_template=wg_array_tmpl_wide,
            delay_lengths=[delay_length * i for i in range(len(array_out_ports))],
            start_ports=array_in_ports,
            end_ports=array_out_ports,
        )
        .Layout(
            taper_length=wg_array_taper_length,
            bundle_spacing=wg_array_bundle_spacing,
            cover_layers=[
                i3.TECH.PPLAYER.FETCH.CLD,
                i3.TECH.PPLAYER.NONE,
                i3.TECH.PPLAYER.BBOX,
                i3.TECH.PPLAYER.DEVREC,
            ],
            route_properties=rprops._get_routing_parameters(),
        )
        .cell
    )

    rect_awg = awg_des.ArrayedWaveguideGrating(star_coupler_in=sc_in, star_coupler_out=sc_out, waveguide_array=array)

    ####################################################################################################################
    # Step 8. Clean up the AWG to get rid of design rule violations. Two types of violations may occur in the AWG:
    # - acute (sharp) angles
    # - snapping errors
    # We use get_stub_elements and flat_copy to fix these.
    print("Step 8. Clean up the AWG to get rid of design rule violations")

    rect_awg_layout = rect_awg.get_default_view(i3.LayoutView)
    rect_awg_netlist = rect_awg.get_default_view(i3.NetlistView)
    rect_awg_circuit = rect_awg.get_default_view(i3.CircuitModelView)

    elems_add, elems_subt = i3.get_stub_elements(
        layout=rect_awg_layout,
        angle_threshold=0,
        layers=[i3.TECH.PPLAYER.FETCH.COR],
        grow_amount=0.001,
    )
    rect_awg_stubbed = i3.EmptyCell(name="awg_clean")
    rect_awg_stubbed_layout = rect_awg_stubbed.Layout(
        layout=rect_awg_layout.layout.flat_copy() + elems_add,
        ports=rect_awg_layout.ports,
    )
    rect_awg_stubbed.Netlist(terms=rect_awg_netlist.terms)
    # rect_awg_stubbed.CircuitModel(model=rect_awg_circuit.model)

    if visualize:
        rect_awg_stubbed_layout.visualize(annotate=True)

    if write_gds:
        rect_awg_stubbed_layout.flat_copy().write_gdsii("rect_awg_strip_wg_apertures{}.gds".format(tag))
        print("{} written.".format("rect_awg_strip_wg_apertures{}.gds".format(tag)))

    # if simulate:
    #     print("Simulating spectrum")
    #     awg_cm = rect_awg_stubbed.get_default_view(i3.CircuitModelView)
    #     channel_spacing_um = np.mean(wavelengths[1::] - wavelengths[0:-1])
    #     wl_min = min(wavelengths) - n_channels * channel_spacing_um
    #     wl_max = max(wavelengths) + n_channels * channel_spacing_um
    #     sim_wavelengths = np.linspace(wl_min, wl_max, 1001)
    #     s_matrix = awg_cm.get_smatrix(sim_wavelengths)
    #     for index in range(n_channels):
    #         spectrum = 10.0 * np.log10(np.abs(s_matrix["out{}".format(index + 1), "in1"]) ** 2.0)
    #         plt.plot(sim_wavelengths, spectrum, "-", label="out{}".format(index + 1))
    #     plt.show()
    rect_awg.Layout()
    return rect_awg
